# Automatic stream failover

Both apps preserve the existing encrypted `streams` string format and support optional backup endpoints per quality.

Example (the first URL is primary; later URLs are tried in order):

```json
{
  "name": "Channel name",
  "streams": {
    "HD": ["ENCRYPTED_OR_PLAIN_PRIMARY_URL", "ENCRYPTED_OR_PLAIN_BACKUP_1", "ENCRYPTED_OR_PLAIN_BACKUP_2"],
    "SD": "EXISTING_ENCRYPTED_OR_PLAIN_URL"
  },
  "backupStreams": {
    "SD": ["BACKUP_SD_1", "BACKUP_SD_2"]
  }
}
```

- Existing `streams: {"HD":"..."}` records remain compatible.
- Every endpoint may use the same encrypted URL representation already understood by `SecurityUtils.decrypt`.
- On a playback error, the player moves immediately to the next configured endpoint for the same quality before retrying the failed endpoint or falling back to another quality.
- A buffering watchdog also advances to the next backup if the current source remains stuck.
- The app cannot guarantee a 300 ms recovery from an arbitrary network outage: detection time depends on Media3, the device, and the source. True sub-300 ms seamless failover requires a warm standby stream and sufficient network capacity.
