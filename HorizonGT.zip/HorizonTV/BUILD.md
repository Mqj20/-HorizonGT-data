# Horizon GT build

## GitHub Actions

1. ارفع ملفات المشروع إلى مستودع البناء.
2. افتح **Actions**.
3. اختر **Build Horizon GT APK**.
4. اضغط **Run workflow** عند الحاجة.
5. بعد نجاح البناء افتح الـArtifact ونزّل APK.

## مصدر المحتوى

لا يحتاج APK إلى إعادة بناء عند تعديل القنوات أو Xtream. التطبيق يقرأ ملف `content.json` البعيد:

`https://raw.githubusercontent.com/Mqj20/horizon-data/main/content.json`

لذلك اجعل هذا الملف هو ملف التحكم الوحيد في البيانات.

## ملاحظة التوقيع

للتحديث فوق نسخة مثبتة سابقاً يجب استخدام نفس مفتاح التوقيع.
