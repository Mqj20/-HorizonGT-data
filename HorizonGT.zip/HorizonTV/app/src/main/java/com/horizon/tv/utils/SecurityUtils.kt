package com.horizon.tv.utils

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

object SecurityUtils {

    private const val ALGORITHM = "AES/CBC/PKCS5Padding"
    private const val TRANSFORMATION = "AES"

    // الصيغة القديمة (AES-CBC): تبقى مدعومة حتى لا تتأثر الروابط الحالية.
    private val SECRET_KEY_BYTES =
        "HorizonSecret26!".toByteArray(Charsets.UTF_8)
    private val IV_BYTES =
        "HorizonInitVec1!".toByteArray(Charsets.UTF_8)

    // الصيغة الجديدة (AES-256-GCM): تبدأ دائماً بالبادئة HZ2:
    private const val GCM_PREFIX = "HZ2:"
    private val GCM_KEY: SecretKeySpec by lazy {
        SecretKeySpec(
            MessageDigest.getInstance("SHA-256")
                .digest("HorizonGCM#2026-key".toByteArray(Charsets.UTF_8)),
            "AES"
        )
    }

    fun encrypt(plainText: String): String {
        return try {
            val keySpec = SecretKeySpec(SECRET_KEY_BYTES, TRANSFORMATION)
            val ivSpec = IvParameterSpec(IV_BYTES)
            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec)
            val encryptedBytes = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            Base64.encodeToString(encryptedBytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            ""
        }
    }

    fun encryptGcm(plainText: String): String {
        return try {
            val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, GCM_KEY, GCMParameterSpec(128, iv))
            val ct = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            GCM_PREFIX + Base64.encodeToString(iv + ct, Base64.NO_WRAP)
        } catch (e: Exception) {
            ""
        }
    }

    private fun decryptGcm(text: String): String {
        return try {
            val raw = Base64.decode(text.removePrefix(GCM_PREFIX), Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, GCM_KEY, GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            String(cipher.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }

    /** يفك الصيغتين تلقائياً: HZ2: (GCM) أو Base64 القديم (CBC). يرجع "" عند الفشل. */
    fun decrypt(encryptedText: String): String {
        if (encryptedText.startsWith(GCM_PREFIX)) return decryptGcm(encryptedText)
        return try {
            val keySpec = SecretKeySpec(SECRET_KEY_BYTES, TRANSFORMATION)
            val ivSpec = IvParameterSpec(IV_BYTES)
            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec)
            val decodedBytes = Base64.decode(encryptedText, Base64.NO_WRAP)
            String(cipher.doFinal(decodedBytes), Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }
}
