package com.horizon.tv

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * عدّاد مجهول: معرّف عشوائي فقط (لا اسم ولا رقم هاتف ولا بيانات شخصية).
 * - عند فتح التطبيق: يُحسب "محمّل" (مرة واحدة لكل جهاز) و"فاتح الآن".
 * - أثناء بقاء التطبيق مفتوحاً: نبضة كل دقيقتين لتبقى "فاتح الآن" صحيحة.
 * اترك STATS_URL فارغاً = لا يُرسل شيء.
 */
object Stats {
    // ضع هنا رابط الـ Worker بعد نشره، مثل: https://horizon-stats.YOURNAME.workers.dev/hit
    private const val STATS_URL = "https://horizon-stats.kwndyvv.workers.dev/hit"
    private const val BEAT_MS = 120_000L

    private val ui = Handler(Looper.getMainLooper())
    private var beat: Runnable? = null

    fun start(ctx: Context, mode: String, versionName: String) {
        if (STATS_URL.isBlank()) return
        stop()
        val app = ctx.applicationContext
        send(app, mode, versionName, false)
        val r = object : Runnable {
            override fun run() {
                send(app, mode, versionName, true)
                ui.postDelayed(this, BEAT_MS)
            }
        }
        beat = r
        ui.postDelayed(r, BEAT_MS)
    }

    fun stop() {
        beat?.let { ui.removeCallbacks(it) }
        beat = null
    }

    private fun send(app: Context, mode: String, versionName: String, heartbeat: Boolean) {
        Thread {
            runCatching {
                val prefs = app.getSharedPreferences("HorizonPrefs", Context.MODE_PRIVATE)
                var id = prefs.getString("stat_id", null)
                if (id == null) {
                    id = UUID.randomUUID().toString()
                    prefs.edit().putString("stat_id", id).apply()
                }
                val body = JSONObject().put("id", id).put("v", versionName)
                    .put("mode", mode).put("hb", heartbeat).toString()
                val c = URL(STATS_URL).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 6000
                c.readTimeout = 6000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
                c.responseCode
                c.disconnect()
            }
        }.start()
    }
}
