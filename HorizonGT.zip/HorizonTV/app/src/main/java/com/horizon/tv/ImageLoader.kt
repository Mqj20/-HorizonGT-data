package com.horizon.tv

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** يجلب الشعارات والبوسترات من روابطها ويعرضها، مع ذاكرة تخزين مؤقت وتصغير للصور الكبيرة. */
object ImageLoader {
    private val cache = LruCache<String, Bitmap>(250)
    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(6)

    /** يتبع التحويلات بين http و https (HttpURLConnection لا يفعل ذلك وحده) ويصغّر الصورة لتوفير الذاكرة. */
    private fun download(url: String): Bitmap? {
        var current = url.trim()
        repeat(5) {
            val c = URL(current).openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = 15000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11) HorizonTV/3.0")
            c.setRequestProperty("Accept", "image/*,*/*")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: return null
                current = URL(URL(current), loc).toString()
                c.disconnect()
                return@repeat
            }
            if (code !in 200..299) { c.disconnect(); return null }
            val bytes = c.inputStream.use { it.readBytes() }
            c.disconnect()
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 400 && bounds.outHeight / (sample * 2) >= 600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        }
        return null
    }

    /** تحميل مسبق إلى الذاكرة حتى تظهر الصورة فوراً عند الحاجة. */
    fun prefetch(url: String) {
        if (url.isBlank() || cache.get(url) != null) return
        pool.execute {
            val bmp = runCatching { download(url) }.getOrNull()
            if (bmp != null) cache.put(url, bmp)
        }
    }

    /** يُضبط من MainActivity: يسمح بتحميل صور من داخل التطبيق بصيغة "asset:اسم.png" (فوري وبلا إنترنت). */
    var assets: android.content.res.AssetManager? = null

    private fun decodeAsset(url: String): Bitmap? = try {
        assets?.open(url.removePrefix("asset:"))?.use { BitmapFactory.decodeStream(it) }
    } catch (e: Exception) { null }

    /** يحمّل الصورة في ImageView؛ رابط فارغ أو فاشل يترك المربع بلا صورة (الاسم يبقى ظاهراً). */
    fun load(url: String, into: ImageView) {
        into.setImageDrawable(null)
        into.tag = url
        if (url.isBlank()) return
        if (url.startsWith("asset:")) {
            val b = cache.get(url) ?: decodeAsset(url)?.also { cache.put(url, it) }
            if (b != null) into.setImageBitmap(b)
            return
        }
        cache.get(url)?.let { into.setImageBitmap(it); return }
        pool.execute {
            val bmp = runCatching { download(url) }.getOrNull()
            if (bmp != null) {
                cache.put(url, bmp)
                ui.post { if (into.tag == url) into.setImageBitmap(bmp) }
            }
        }
    }
}
