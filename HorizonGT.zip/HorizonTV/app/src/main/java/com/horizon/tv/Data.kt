package com.horizon.tv

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** شعار خاص يظهر فوق الفيديو (لتغطية شعار القناة الأصلي): pos = tl/tr/bl/br، العرض كنسبة % من عرض الفيديو. */
data class Overlay(
    val url: String, val pos: String = "tr", val widthPct: Float = 12f, val bg: Int? = null,
    /** ارتفاع الصندوق كنسبة % من ارتفاع الفيديو (0 = حسب الصورة). مفيد لتغطية شعار القناة الأصلي بالكامل. */
    val heightPct: Float = 0f, val mx: Int = 0, val my: Int = 0
)
data class Channel(
    val name: String,
    val streams: Map<String, String>,
    val logo: String = "",
    /** روابط بديلة اختيارية لكل جودة؛ تبقى الصيغة القديمة مدعومة. */
    val backupStreams: Map<String, List<String>> = emptyMap(),
    val overlay: Overlay? = null,
    /** اسم قناة أو رابط بث: يُؤخذ منه الصوت تلقائياً ويُكتم صوت هذه القناة. */
    val audioFrom: String = ""
)
data class Group(val name: String, val channels: List<Channel>)
data class M3uSource(val name: String, val url: String)
data class XtreamConfig(val host: String, val username: String, val password: String)
data class XtreamMovie(val name: String, val streamId: Int, val extension: String, val logo: String, val categoryId: String)
data class XtreamSeriesItem(val name: String, val seriesId: Int, val logo: String, val categoryId: String)
data class XtreamEpisode(val name: String, val episodeId: Int, val extension: String, val logo: String, val season: Int, val episode: Int)
data class Series(val name: String, val seasons: List<Pair<String, List<Channel>>>)
data class SeriesGroup(val name: String, val items: List<Series>)
data class Match(
    val date: String, val time: String, val tz: String,
    val league: String, val home: String, val away: String, val channel: String
)
data class AppInfo(val version: Int, val apkUrl: String, val notes: String, val minVersion: Int = 0)
data class Content(
    val codeHashes: Set<String>,
    val app: AppInfo?,
    val channels: List<Group>,
    val m3uSources: List<M3uSource>,
    val movies: List<Group>,
    val series: List<SeriesGroup>,
    val matches: List<Match>,
    val servers: List<M3uSource> = emptyList(),
    val xtream: XtreamConfig? = null,
    /** تحديث خاص بكل تطبيق: المفتاح هو اسم الحزمة (com.horizon.gt / com.horizon.tv). */
    val apps: Map<String, AppInfo> = emptyMap(),
    /** إغلاق التطبيق عند اكتشاف VPN/بروكسي؛ يمكن إيقافه من content.json: "security": {"blockVpn": false} */
    val blockVpn: Boolean = true
)

object ChannelRepository {
    /**
     * المصدر الوحيد للمحتوى: ملف content.json الموجود على GitHub.
     * أي تعديل/إضافة/حذف في الملف ينعكس على التطبيق عند إعادة تحميل المحتوى
     * بدون الحاجة إلى إعادة بناء APK.
     *
     * ملاحظة: يجب أن يكون مستودع البيانات عاماً، لأن التطبيق لا يمكنه الوصول
     * إلى raw.githubusercontent.com داخل مستودع GitHub خاص بدون رمز وصول.
     */
    const val CONFIG_URL = "https://raw.githubusercontent.com/Mqj20/horizon-data/main/content_v2.json"

    @Volatile var lastSource: String = ""
    @Volatile var lastError: String = ""

    fun load(ctx: Context, done: (Content?) -> Unit) {
        val ui = Handler(Looper.getMainLooper())
        Thread {
            var content: Content? = null
            var error = ""

            try {
                val text = fetch(CONFIG_URL + "?t=" + System.currentTimeMillis())
                content = parse(text)
                lastSource = "الإنترنت"
            } catch (e: Exception) {
                error = e.message ?: "فشل تحميل content.json"
                lastSource = "فشل"
            }

            lastError = error
            ui.post { done(content) }
        }.start()
    }

    private fun fetch(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 20000
        c.useCaches = false
        c.instanceFollowRedirects = true
        c.requestMethod = "GET"
        c.setRequestProperty("User-Agent", "Horizon-GT/1.0")
        c.setRequestProperty("Accept", "application/json,text/plain,*/*")
        c.setRequestProperty("Cache-Control", "no-cache")
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream)
            ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (code !in 200..299) throw java.io.IOException("content.json HTTP $code")
        if (body.isBlank()) throw java.io.IOException("content.json فارغ")
        return body.trimStart('\uFEFF').trim()
    }

    private fun <T> JSONArray?.mapObjects(f: (JSONObject) -> T): List<T> {
        if (this == null) return emptyList()
        return (0 until length()).mapNotNull { i -> optJSONObject(i)?.let(f) }
    }

    private data class ParsedStreams(
        val primary: Map<String, String>,
        val backups: Map<String, List<String>>
    )

    /**
     * يدعم الصيغة القديمة quality: "url"، ويدعم أيضاً quality: ["primary", "backup1"].
     * كما يقبل backupStreams: { quality: ["backup1", "backup2"] }.
     */
    private fun streamsOf(x: JSONObject, single: String): ParsedStreams {
        val primary = linkedMapOf<String, String>()
        val backups = linkedMapOf<String, List<String>>()
        val so = x.optJSONObject("streams")
        if (so != null) {
            so.keys().forEach { quality ->
                val raw = so.opt(quality)
                val urls = when (raw) {
                    is JSONArray -> (0 until raw.length()).mapNotNull { i ->
                        raw.optString(i).takeIf { it.isNotBlank() && it != "null" }
                    }
                    is String -> listOf(raw).filter { it.isNotBlank() && it != "null" }
                    else -> emptyList()
                }
                urls.firstOrNull()?.let { primary[quality] = it }
                if (urls.size > 1) backups[quality] = urls.drop(1)
            }
        } else {
            x.optString("url").takeIf { it.isNotBlank() }?.let { primary[single] = it }
        }

        val backupObject = x.optJSONObject("backupStreams")
        if (backupObject != null) {
            backupObject.keys().forEach { quality ->
                val raw = backupObject.opt(quality)
                val urls = when (raw) {
                    is JSONArray -> (0 until raw.length()).mapNotNull { i ->
                        raw.optString(i).takeIf { it.isNotBlank() && it != "null" }
                    }
                    is String -> listOf(raw).filter { it.isNotBlank() && it != "null" }
                    else -> emptyList()
                }
                if (urls.isNotEmpty()) backups[quality] = (backups[quality].orEmpty() + urls).distinct()
            }
        }
        return ParsedStreams(primary, backups)
    }

    /** يقبل "overlay": "رابط" أو "overlay": {"url","pos","width","bg"} */
    private fun overlayOf(raw: Any?): Overlay? = when (raw) {
        is String -> raw.takeIf { it.isNotBlank() && it != "null" }?.let { Overlay(it) }
        is JSONObject -> raw.optString("url").takeIf { it.isNotBlank() }?.let { u ->
            Overlay(
                u,
                raw.optString("pos", "tr").lowercase(),
                raw.optDouble("width", 12.0).toFloat().coerceIn(3f, 60f),
                raw.optString("bg").takeIf { it.isNotBlank() }?.let { runCatching { android.graphics.Color.parseColor(it) }.getOrNull() },
                raw.optDouble("height", 0.0).toFloat().coerceIn(0f, 60f),
                raw.optInt("mx", 0),
                raw.optInt("my", 0)
            )
        }
        else -> null
    }

    /** الشعار قد يكون مشفراً (نفس صيغة روابط البث): نفكه، وإلا نبقيه كما هو. */
    private fun plainLogo(raw: String): String {
        val s = raw.trim()
        if (s.isEmpty() || s.startsWith("http", true) || s.startsWith("asset:")) return s
        val d = com.horizon.tv.utils.SecurityUtils.decrypt(s)
        return if (d.startsWith("http://") || d.startsWith("https://")) d else s
    }

    private fun channelOf(x: JSONObject, single: String, groupOverlay: Overlay? = null, groupAudio: String = ""): Channel {
        val parsed = streamsOf(x, single)
        val name = x.optString("name")
        var own = if (x.has("overlay")) overlayOf(x.opt("overlay")) else groupOverlay
        // {n} داخل رابط الشعار يُستبدل برقم القناة الأخير (Horizon Sport 3 ← 3)
        if (own != null && own.url.contains("{n}")) {
            val n = Regex("(\\d+)\\s*$").find(name.trim())?.groupValues?.get(1) ?: ""
            own = own.copy(url = own.url.replace("{n}", n))
        }
        return Channel(name, parsed.primary, plainLogo(x.optString("logo")), parsed.backups, own, x.optString("audioFrom", groupAudio))
    }

    private fun groups(a: JSONArray?, single: String): List<Group> =
        a.mapObjects { g ->
            val gOverlay = overlayOf(g.opt("overlay"))
            val gAudio = g.optString("audioFrom")
            Group(
                g.optString("name"),
                g.optJSONArray("channels").mapObjects { channelOf(it, single, gOverlay, gAudio) }
                    .ifEmpty { g.optJSONArray("items").mapObjects { channelOf(it, single, gOverlay, gAudio) } }
                    .filter { it.name.isNotBlank() && it.streams.isNotEmpty() }
            )
        }.filter { it.name.isNotBlank() }

    private fun parse(s: String): Content {
        val o = JSONObject(s)
        val hashes = o.optJSONArray("codeHashes")?.let { a ->
            (0 until a.length()).map { a.getString(it) }.toSet()
        } ?: emptySet()

        val app = o.optJSONObject("app")?.let {
            AppInfo(
                it.optInt("version", 0),
                it.optString("apkUrl"),
                it.optString("notes"),
                it.optInt("minVersion", 0)
            )
        }

        val apps = HashMap<String, AppInfo>()
        o.optJSONObject("app")?.let { a ->
            val keys = a.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                a.optJSONObject(k)?.let { v ->
                    apps[k] = AppInfo(v.optInt("version", 0), v.optString("apkUrl"), v.optString("notes"), v.optInt("minVersion", 0))
                }
            }
        }

        val series = o.optJSONArray("series").mapObjects { g ->
            SeriesGroup(
                g.optString("name"),
                g.optJSONArray("items").mapObjects { sr ->
                    Series(
                        sr.optString("name"),
                        sr.optJSONArray("seasons").mapObjects { se ->
                            Pair(
                                se.optString("name"),
                                se.optJSONArray("episodes").mapObjects {
                                    channelOf(it, "VOD")
                                }.filter { it.streams.isNotEmpty() }
                            )
                        }
                    )
                }
            )
        }

        val matches = o.optJSONArray("matches").mapObjects {
            Match(
                it.optString("date"), it.optString("time"), it.optString("tz"),
                it.optString("league"), it.optString("home"), it.optString("away"),
                it.optString("channel")
            )
        }

        val m3u = o.optJSONArray("m3uSources").mapObjects { x ->
            M3uSource(x.optString("name"), x.optString("url"))
        }.filter { it.name.isNotBlank() && it.url.isNotBlank() }

        val servers = o.optJSONArray("moviesSeriesServers").mapObjects { x ->
            M3uSource(x.optString("name"), x.optString("url"))
        }.filter { it.name.isNotBlank() && it.url.isNotBlank() }

        // Xtream configuration is controlled entirely from content.json.
        // Keep the credentials encrypted with the same project SecurityUtils.
        val xt = o.optJSONObject("xtream")?.takeIf { it.optBoolean("enabled", true) }?.let { x ->
            // بيانات Xtream مصدرها content.json فقط؛ يقبل النص العادي أو AES/Base64.
            fun dec(key: String): String {
                val raw = x.optString(key).trim()
                if (raw.isBlank() || raw == "null") return ""
                val decrypted = com.horizon.tv.utils.SecurityUtils.decrypt(raw).trim()
                return decrypted.ifBlank { raw }
            }

            val rawHost = dec("url").ifBlank { dec("host") }.trim().trimEnd('/')
            val normalizedHost = when {
                rawHost.startsWith("https://", true) || rawHost.startsWith("http://", true) -> rawHost
                rawHost.isNotBlank() -> "http://$rawHost"
                else -> ""
            }.removeSuffix("/player_api.php")

            XtreamConfig(
                host = normalizedHost,
                username = dec("username"),
                password = dec("password")
            )
        }?.takeIf {
            it.host.isNotBlank() && it.username.isNotBlank() && it.password.isNotBlank()
        }

        return Content(
            codeHashes = hashes,
            app = app,
            channels = groups(o.optJSONArray("channels"), "HD"),
            m3uSources = m3u,
            movies = groups(o.optJSONArray("movies"), "VOD"),
            series = series,
            matches = matches,
            servers = servers,
            xtream = xt,
            apps = apps,
            blockVpn = o.optJSONObject("security")?.optBoolean("blockVpn", true) ?: true
        )
    }
}

object Activation {
    private const val PREFS = "HorizonPrefs"
    private const val KEY = "isActivated_v2"

    fun isActivated(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, false)

    fun tryActivate(c: Context, code: String, hashes: Set<String>): Boolean {
        val ok = sha256(code.trim()) in hashes
        if (ok) c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, true).apply()
        return ok
    }

    fun sha256(s: String) = MessageDigest.getInstance("SHA-256")
        .digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}


object XtreamRepository {
    private fun base(c: XtreamConfig): String {
        val host = c.host.trim().trimEnd('/').removeSuffix("/player_api.php")
        return "$host/player_api.php"
    }

    private fun query(c: XtreamConfig, params: Map<String, String>): String {
        val q = linkedMapOf("username" to c.username, "password" to c.password).apply { putAll(params) }
        return q.entries.joinToString("&") {
            java.net.URLEncoder.encode(it.key, "UTF-8") + "=" +
                java.net.URLEncoder.encode(it.value, "UTF-8")
        }
    }

    private fun request(c: XtreamConfig, params: Map<String, String>): String {
        if (c.host.isBlank() || c.username.isBlank() || c.password.isBlank()) {
            throw java.io.IOException("بيانات Xtream ناقصة داخل content.json")
        }
        val url = URL(base(c) + "?" + query(c, params))
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 20000
            conn.readTimeout = 45000
            conn.useCaches = false
            conn.instanceFollowRedirects = true
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", "Horizon-GT/1.0")
            conn.setRequestProperty("Accept", "application/json,text/plain,*/*")
            val code = conn.responseCode
            val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                throw java.io.IOException("Xtream HTTP $code: ${body.take(240)}")
            }
            if (body.isBlank()) throw java.io.IOException("سيرفر Xtream أعاد استجابة فارغة")
            return body.trimStart('\uFEFF').trim()
        } finally {
            conn.disconnect()
        }
    }

    private fun array(c: XtreamConfig, params: Map<String, String>): JSONArray {
        val body = request(c, params)
        return try {
            JSONArray(body)
        } catch (_: Exception) {
            val o = runCatching { JSONObject(body) }.getOrNull()
            val wrapped = o?.optJSONArray("data") ?: o?.optJSONArray("results")
            if (wrapped != null) return wrapped
            val message = o?.optString("message").orEmpty()
                .ifBlank { o?.optString("error").orEmpty() }
                .ifBlank { "استجابة Xtream ليست قائمة JSON: ${body.take(160)}" }
            throw java.io.IOException(message)
        }
    }

    private fun objectResponse(c: XtreamConfig, params: Map<String, String>): JSONObject {
        val body = request(c, params)
        return try {
            JSONObject(body)
        } catch (_: Exception) {
            throw java.io.IOException("استجابة Xtream غير صالحة")
        }
    }

    fun movies(c: XtreamConfig, done: (Result<List<Pair<String, List<XtreamMovie>>>>) -> Unit) {
        Thread {
            runCatching {
                val cats = array(c, mapOf("action" to "get_vod_categories"))
                val streams = array(c, mapOf("action" to "get_vod_streams"))
                val catNames = HashMap<String, String>()
                for (i in 0 until cats.length()) {
                    val x = cats.optJSONObject(i) ?: continue
                    val id = x.optString("category_id")
                    if (id.isNotBlank()) catNames[id] = x.optString("category_name", "أفلام")
                }
                val grouped = linkedMapOf<String, MutableList<XtreamMovie>>()
                for (i in 0 until streams.length()) {
                    val x = streams.optJSONObject(i) ?: continue
                    val id = x.optInt("stream_id", 0)
                    if (id <= 0) continue
                    val catId = x.optString("category_id")
                    val cat = catNames[catId].orEmpty().ifBlank { "أفلام" }
                    val ext = x.optString("container_extension", "mp4").ifBlank { "mp4" }
                    grouped.getOrPut(cat) { mutableListOf() }.add(
                        XtreamMovie(
                            x.optString("name", "فيلم"),
                            id,
                            ext,
                            x.optString("stream_icon"),
                            catId
                        )
                    )
                }
                if (grouped.isEmpty()) throw java.io.IOException("Xtream لم يُرجع أي أفلام")
                grouped.entries.map { it.key to it.value.toList() }
            }.fold({ done(Result.success(it)) }, { done(Result.failure(it)) })
        }.start()
    }

    fun series(c: XtreamConfig, done: (Result<List<Pair<String, List<XtreamSeriesItem>>>>) -> Unit) {
        Thread {
            runCatching {
                val cats = array(c, mapOf("action" to "get_series_categories"))
                val all = array(c, mapOf("action" to "get_series"))
                val catNames = HashMap<String, String>()
                for (i in 0 until cats.length()) {
                    val x = cats.optJSONObject(i) ?: continue
                    val id = x.optString("category_id")
                    if (id.isNotBlank()) catNames[id] = x.optString("category_name", "مسلسلات")
                }
                val grouped = linkedMapOf<String, MutableList<XtreamSeriesItem>>()
                for (i in 0 until all.length()) {
                    val x = all.optJSONObject(i) ?: continue
                    val id = x.optInt("series_id", 0)
                    if (id <= 0) continue
                    val catId = x.optString("category_id")
                    val cat = catNames[catId].orEmpty().ifBlank { "مسلسلات" }
                    grouped.getOrPut(cat) { mutableListOf() }.add(
                        XtreamSeriesItem(
                            x.optString("name", "مسلسل"),
                            id,
                            x.optString("cover").ifBlank { x.optString("cover_big") },
                            catId
                        )
                    )
                }
                if (grouped.isEmpty()) throw java.io.IOException("Xtream لم يُرجع أي مسلسلات")
                grouped.entries.map { it.key to it.value.toList() }
            }.fold({ done(Result.success(it)) }, { done(Result.failure(it)) })
        }.start()
    }

    fun episodes(c: XtreamConfig, seriesId: Int, done: (Result<List<Pair<String, List<XtreamEpisode>>>>) -> Unit) {
        Thread {
            runCatching {
                val o = objectResponse(c, mapOf("action" to "get_series_info", "series_id" to seriesId.toString()))
                val seasons = o.optJSONObject("episodes")
                    ?: throw java.io.IOException("Xtream لم يُرجع حلقات لهذا المسلسل")
                val grouped = linkedMapOf<String, MutableList<XtreamEpisode>>()
                val seasonKeys = seasons.keys().asSequence().toList()
                    .sortedWith(compareBy { it.toIntOrNull() ?: Int.MAX_VALUE })
                for (seasonKey in seasonKeys) {
                    val seasonArray = seasons.optJSONArray(seasonKey) ?: continue
                    for (j in 0 until seasonArray.length()) {
                        val x = seasonArray.optJSONObject(j) ?: continue
                        val id = x.optInt("id", 0)
                        if (id <= 0) continue
                        val sn = x.optInt("season", seasonKey.toIntOrNull() ?: 1)
                        val ep = x.optInt("episode_num", j + 1)
                        val key = "الموسم $sn"
                        val ext = x.optString("container_extension", "mp4").ifBlank { "mp4" }
                        grouped.getOrPut(key) { mutableListOf() }.add(
                            XtreamEpisode(
                                x.optString("title", "الحلقة $ep"),
                                id,
                                ext,
                                x.optString("movie_image").ifBlank { x.optString("movie_image_big") },
                                sn,
                                ep
                            )
                        )
                    }
                }
                if (grouped.isEmpty()) throw java.io.IOException("Xtream لم يُرجع حلقات")
                grouped.entries.map { it.key to it.value.sortedBy { e -> e.episode } }
            }.fold({ done(Result.success(it)) }, { done(Result.failure(it)) })
        }.start()
    }

    fun movieUrl(c: XtreamConfig, id: Int, ext: String) =
        "${c.host.trimEnd('/')}/movie/${c.username}/${c.password}/$id.${ext.ifBlank { "mp4" }}"

    fun episodeUrl(c: XtreamConfig, id: Int, ext: String) =
        "${c.host.trimEnd('/')}/series/${c.username}/${c.password}/$id.${ext.ifBlank { "mp4" }}"
}

