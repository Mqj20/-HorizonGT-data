package com.horizon.tv

import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.app.UiModeManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Rational
import android.view.Gravity
import android.view.GestureDetector
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.common.MimeTypes
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.media3.ui.TrackSelectionDialogBuilder
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class MainActivity : AppCompatActivity() {

    private enum class Screen { ACTIVATION, LIST, PLAYER }

    private data class Row(
        val key: String,
        val title: String,
        val badges: List<String> = emptyList(),
        val trailing: String? = null,
        val isFavorite: Boolean = false
    )

    private data class Entry(val title: String, val sub: String, val streams: Map<String, String>)

    // ---- Aurora palette ----
    private val BG = Color.parseColor("#0A0B0F")
    private val CARD = Color.parseColor("#14161C")
    private val CARD_FOCUS = Color.parseColor("#1E2129")
    private val ACCENT = Color.parseColor("#F5B83D")
    private val ACCENT2 = Color.parseColor("#FF8A5B")
    private val ACCENT_SOFT = Color.parseColor("#26F5B83D")
    private val TEXT_MAIN = Color.parseColor("#F4F5F7")
    private val MUTED = Color.parseColor("#8A8F9C")
    private val BORDER = Color.parseColor("#1AFFFFFF")
    private val DANGER = Color.parseColor("#FF5D6C")
    private val ON_ACCENT = Color.parseColor("#1A1306")
    private val FONT_MED: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val telegramUrl = "https://t.me/X_9_KKKKK"
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )

    private val main = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var bgView: View
    private val bgDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(Color.parseColor("#1A1409"), Color.parseColor("#0D0D11"), Color.parseColor("#0A0B0F"))
    )
    private var bgAnimator: ValueAnimator? = null
    private lateinit var playerView: PlayerView
    private var player: ExoPlayer? = null
    private var content: Content? = null
    private var screen = Screen.ACTIVATION
    private var retries = 0
    private var resizeIndex = 0
    private var lastClickTime = 0L
    private var updateChecked = false

    // ================= AdMob =================
    private var interstitialAd: InterstitialAd? = null
    private var isAdLoading = false
    private val admobInterstitialId = "ca-app-pub-7243858580920682/1332184888"
    private val admobTestInterstitialId = "ca-app-pub-3940256099942544/1033173712"
    private val useTestAd = false
    private var homeAdShown = false
    private var homeAdWaitAttempts = 0

    // navigation
    private var navBack: (() -> Unit)? = null
    private var webView: WebView? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var loadToken = 0
    private var playerBack: (() -> Unit)? = null
    private var playlist: List<Channel> = emptyList()
    private var playlistTitle = ""
    // آخر قائمة عناصر تفاعلية على الشاشة؛ تُستخدم لتوجيه OK في أجهزة Android TV.
    private var activeAdapterView: AdapterView<*>? = null
    private var panelGroups: List<Group>? = null
    private var panelShowGroups = false
    private var curSub = ""

    // player screen parts
    private lateinit var qualityBar: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var controlsLayer: FrameLayout
    private lateinit var infoCard: LinearLayout
    private lateinit var infoName: TextView
    private lateinit var infoCat: TextView
    private lateinit var liveDot: View
    private lateinit var playPauseChip: ImageView
    private lateinit var muteChip: ImageView
    private lateinit var lockBtn: ImageView
    private lateinit var seekBlock: LinearLayout
    private lateinit var seekBar: SeekBar
    private lateinit var seekCur: TextView
    private lateinit var seekTotal: TextView
    private lateinit var hudBrightness: TextView
    private lateinit var hudVolume: TextView
    private var lockables: List<View> = emptyList()
    private var controlsLocked = false
    private var seekDragging = false
    private var speedIndex = 0
    private val speedSteps = floatArrayOf(1f, 1.25f, 1.5f, 2f, 0.5f, 0.75f)
    private lateinit var buffSpinner: ProgressBar
    private var retryRunnable: Runnable? = null
    private var stallRunnable: Runnable? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var infoFade: Runnable? = null
    private var isMuted = false
    private lateinit var playerGestures: GestureDetector
    private var gestureDownX = 0f
    private var gestureDownY = 0f
    private var gestureMode = 0 // 0 undecided, 1 seek, 2 volume, 3 brightness
    private var gestureStartVolume = 0
    private var gestureMaxVolume = 1
    private var gestureStartBrightness = 0.5f
    private var gestureStartPosition = 0L
    private var lastGestureToast = 0L
    private var curCh: Channel? = null
    private var curQuality = ""
    // لوحة إحصائيات التشغيل (لتشخيص التقطيع)
    private var statsOn = false
    private var statsView: TextView? = null
    private var overlayImg: ImageView? = null
    private var droppedFrames = 0L
    private var lastFrameAt = 0L
    private var lastStallAt = 0L
    private val freezeHits = ArrayList<Long>()
    private var videoDecoder = "-"
    // صوت من قناة أخرى: مشغّل صوتي ثانٍ يعمل فوق فيديو القناة الحالية
    private var extPlayer: ExoPlayer? = null
    private var extName: String? = null
    private var extDelayMs = 0L
    private var extChipView: TextView? = null
    private val hideControls = Runnable {
        if (panel.visibility != View.VISIBLE) controlsLayer.visibility = View.GONE
    }

    // ================= Persistent storage =================

    private fun prefs() = getSharedPreferences("horizon_prefs", MODE_PRIVATE)

    private fun loadList(key: String): MutableList<Entry> {
        val s = prefs().getString(key, null) ?: return mutableListOf()
        return runCatching {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                val u = o.getJSONObject("u")
                val m = linkedMapOf<String, String>()
                u.keys().forEach { k -> m[k] = u.getString(k) }
                Entry(o.getString("t"), o.optString("s"), m)
            }.toMutableList()
        }.getOrDefault(mutableListOf())
    }

    private fun saveList(key: String, list: List<Entry>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("t", it.title).put("s", it.sub).put("u", JSONObject(it.streams)))
        }
        prefs().edit().putString(key, a.toString()).apply()
    }

    private fun firstUrl(e: Entry) = e.streams.values.firstOrNull().orEmpty()

    private fun pushRecent(e: Entry) {
        val list = loadList("recents")
        list.removeAll { firstUrl(it) == firstUrl(e) }
        list.add(0, e)
        saveList("recents", list.take(15))
    }

    private fun toggleFav(e: Entry): Boolean {
        val list = loadList("favs")
        val had = list.removeAll { firstUrl(it) == firstUrl(e) }
        if (!had) list.add(0, e)
        saveList("favs", list)
        return !had
    }

    // ================= Lifecycle =================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ImageLoader.assets = applicationContext.assets

        // يحفظ سبب أي انهيار ليظهر في التشغيل التالي (للتشخيص)
        val oldHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                prefs().edit().putString(
                    "lastCrash", e.toString() + "\n" + e.stackTrace.take(8).joinToString("\n")
                ).commit()
            } catch (_: Throwable) {}
            oldHandler?.uncaughtException(t, e)
        }

        root = FrameLayout(this).apply { setBackgroundColor(BG) }
        bgView = View(this).apply { background = bgDrawable }
        root.addView(bgView, MATCH, MATCH)
        setContentView(root)
        initializeAdMob()
        playerView = PlayerView(this)
        startBackground()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goBack()
        })
        load()
        reportLastCrash()
    }

    private fun reportLastCrash() {
        val crash = prefs().getString("lastCrash", null) ?: return
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("تم تسجيل خطأ سابق")
            .setMessage(crash)
            .setPositiveButton("حسناً") { _, _ -> prefs().edit().remove("lastCrash").apply() }
            .show()
    }

    /** خلفية متحركة هادئة (تتوقف تلقائياً أثناء تشغيل القناة). */
    private fun startBackground() {
        // خلفية ثابتة هادئة
    }

    private fun showLoading(msg: String = "جارٍ التحميل...") {
        screen = Screen.LIST
        show(column().apply {
            gravity = Gravity.CENTER
            addView(roundedLogo(110, 26).also { pulse(it) })
            addView(ProgressBar(this@MainActivity).apply {
                indeterminateTintList = ColorStateList.valueOf(ACCENT)
            }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { topMargin = dp(24) })
            addView(label(msg))
        })
    }

    private fun load() {
        showLoading()
        ChannelRepository.load(this) { c ->
            content = c
            prefetchOverlays(c)
            applySecurity(c)
            if (c == null) {
                showError("تعذّر تحميل المحتوى", ChannelRepository.lastError) { load() }
            } else {
                checkAppUpdate(c)
                reportSource()
                pruneFavorites(c)
                // التفعيل المباشر بالرقم 27 مع حفظ الحالة بشكل دائم
                val overrideActive = prefs().getBoolean("is_activated_override", false)
                if (overrideActive || Activation.isActivated(this)) {
                    showHome()
                } else showActivation()
            }
        }
    }

    /** تحديث المحتوى من GitHub بدون إعادة تثبيت التطبيق. */
    /** يوضح للمستخدم حالة تحميل content.json من GitHub. */
    private fun reportSource() {
        if (ChannelRepository.lastSource == "الإنترنت") toast("تم تحديث المحتوى")
        else Toast.makeText(this,
            "تعذّر تحميل content.json — ${ChannelRepository.lastError}",
            Toast.LENGTH_LONG).show()
    }

    /** يحذف من المفضلة أي قناة لم تعد موجودة في content.json (بعد قراءة ناجحة من الإنترنت). */
    private fun pruneFavorites(c: Content) {
        val live = c.channels.flatMap { it.channels }.flatMap { it.streams.values }.toSet()
        val groupNames = c.channels.map { it.name }.toSet() + FOURK_SUB
        val favs = loadList("favs")
        val kept = favs.filter { e ->
            e.streams.values.any { it in live } || (c.m3uSources.isNotEmpty() && e.sub !in groupNames)
        }
        if (kept.size != favs.size) saveList("favs", kept)
    }

    private fun reloadContent() {
        showLoading("جارٍ تحديث المحتوى...")
        ChannelRepository.load(this) { c ->
            if (c != null) {
                content = c
                prefetchOverlays(c)
                applySecurity(c)
                checkAppUpdate(c)
                pruneFavorites(c)
            }
            reportSource()
            showHome()
        }
    }

    @Suppress("DEPRECATION")
    private fun currentVersion(): Int = runCatching {
        val pi = packageManager.getPackageInfo(packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else pi.versionCode
    }.getOrDefault(0)

    /** إشعار بوجود نسخة جديدة من التطبيق نفسه (من حقل app في ملف المحتوى). */
    private fun checkAppUpdate(c: Content) {
        if (updateChecked) return
        val app = c.apps[packageName] ?: c.app ?: return
        if (app.version <= currentVersion() || app.apkUrl.isBlank()) return
        updateChecked = true
        // تحديث إجباري: النسخة الحالية أقدم من الحد الأدنى المسموح (minVersion في content.json)
        val force = currentVersion() < app.minVersion
        val b = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(if (force) "هذه النسخة لم تعد مدعومة" else "تحديث جديد متوفر")
            .setMessage(
                if (force) "يجب تحديث التطبيق للمتابعة.\n" + app.notes
                else app.notes.ifBlank { "نسخة جديدة من التطبيق جاهزة للتنزيل." }
            )
            .setPositiveButton("تحديث الآن") { _, _ ->
                downloadAndInstall(app.apkUrl) { if (force) { updateChecked = false; checkAppUpdate(c) } }
            }
        if (force) b.setCancelable(false) else b.setNegativeButton("لاحقاً", null)
        b.show()
    }

    private var pendingApk: java.io.File? = null

    /** ينزّل التحديث داخل التطبيق مع شريط تقدّم، ثم يفتح شاشة التثبيت (فوق النسخة الحالية بدون حذف). */
    private fun downloadAndInstall(url: String, onFail: (() -> Unit)? = null) {
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val pct = TextView(this).apply { text = "0%"; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(8))
            addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(pct, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        }
        var cancelled = false
        val dialog = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("جارٍ تنزيل التحديث")
            .setView(box)
            .setCancelable(false)
            .setNegativeButton("إلغاء") { _, _ -> cancelled = true }
            .show()
        Thread {
            var ok = false
            var file: java.io.File? = null
            try {
                val dir = java.io.File(cacheDir, "updates").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                val f = java.io.File(dir, "update.apk")
                val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 20000
                c.instanceFollowRedirects = true
                c.setRequestProperty("User-Agent", "HorizonUpdater/1.0")
                if (c.responseCode !in 200..299) throw RuntimeException("code ${c.responseCode}")
                val total = c.contentLengthLong
                c.inputStream.use { ins ->
                    f.outputStream().use { outs ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var last = -1
                        while (!cancelled) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            outs.write(buf, 0, n); done += n
                            if (total > 0) {
                                val p = (done * 100 / total).toInt()
                                if (p != last) { last = p; main.post { bar.progress = p; pct.text = "$p%" } }
                            }
                        }
                    }
                }
                // نتأكد أنه ملف APK حقيقي (صيغة ZIP) وليس صفحة خطأ
                val head = f.inputStream().use { s -> ByteArray(2).also { s.read(it) } }
                ok = !cancelled && f.length() > 1_000_000 && head[0] == 0x50.toByte() && head[1] == 0x4B.toByte()
                file = f
            } catch (e: Exception) { ok = false }
            main.post {
                dialog.dismiss()
                when {
                    cancelled -> onFail?.invoke()
                    ok -> file?.let { installApk(it) }
                    else -> { toast("تعذّر تنزيل التحديث، حاول لاحقاً"); onFail?.invoke() }
                }
            }
        }.start()
    }

    private fun installApk(f: java.io.File) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            pendingApk = f
            toast("فعّل «السماح بالتثبيت من هذا التطبيق» ثم ارجع")
            startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        pendingApk = null
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    override fun onResume() {
        super.onResume()
        val f = pendingApk
        if (f != null && f.exists() && (Build.VERSION.SDK_INT < 26 || packageManager.canRequestPackageInstalls())) installApk(f)
    }

    // ================= Screens =================

    private fun showError(msg: String, detail: String = "", retry: () -> Unit) {
        screen = Screen.LIST
        show(column().apply {
            gravity = Gravity.CENTER
            addView(roundedLogo(100, 24).apply { alpha = 0.4f })
            addView(title(msg).apply { setPadding(0, dp(18), 0, dp(6)) })
            addView(label("تأكد من الإنترنت ثم أعد المحاولة"))
            if (detail.isNotBlank()) addView(label(detail).apply { textSize = 12f })
            addView(button("إعادة المحاولة") { retry() },
                LinearLayout.LayoutParams(dp(230), dp(52)).apply { topMargin = dp(18) })
        })
    }

    private fun showActivation() {
        screen = Screen.ACTIVATION
        navBack = null
        val et = EditText(this).apply {
            hint = "كود التفعيل"
            setHintTextColor(MUTED)
            setTextColor(TEXT_MAIN)
            gravity = Gravity.CENTER
            setSingleLine()
            textSize = 20f
            letterSpacing = 0.2f
            typeface = FONT_MED
            background = surface(16, CARD)
        }
        show(column().apply {
            gravity = Gravity.CENTER
            addView(roundedLogo(96, 26), LinearLayout.LayoutParams(WRAP, WRAP).apply { bottomMargin = dp(22) })
            addView(TextView(context).apply {
                text = "Horizon"; setTextColor(TEXT_MAIN); textSize = 30f
                typeface = FONT_MED; gravity = Gravity.CENTER
            })
            addView(label("أدخل كود التفعيل للمتابعة").apply { setPadding(0, dp(6), 0, dp(30)) })
            addView(et, LinearLayout.LayoutParams(dp(300), dp(58)))
            addView(button("تفعيل") {
                val input = et.text.toString().trim()
                if (input == "27") {
                    prefs().edit().putBoolean("is_activated_override", true).apply()
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    showHome()
                } else if (Activation.tryActivate(this@MainActivity, input, content?.codeHashes ?: emptySet())) {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    showHome()
                } else {
                    et.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    ObjectAnimator.ofFloat(et, View.TRANSLATION_X, 0f, -22f, 22f, -14f, 14f, -7f, 7f, 0f)
                        .setDuration(420).start()
                    toast("الكود غير صحيح")
                }
            }, LinearLayout.LayoutParams(dp(300), dp(54)).apply { topMargin = dp(14) })
            addView(button("الحصول على الكود", filled = false) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(telegramUrl)))
            }, LinearLayout.LayoutParams(dp(300), dp(54)).apply { topMargin = dp(10) })
        })
    }

    // اختيار نمط الجهاز بعد نجاح التفعيل: تخطيط متجاوب مع التلفزيون والريموت.
    private fun showDeviceChooser() {
        screen = Screen.LIST
        navBack = null
        val tv = isTvDevice() || (resources.displayMetrics.widthPixels > resources.displayMetrics.heightPixels && resources.configuration.smallestScreenWidthDp >= 600)
        setFullscreen(tv)
        if (tv) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        val contentColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            val side = if (tv) 36 else 20
            setPadding(dp(side), dp(if (tv) 18 else 24), dp(side), dp(if (tv) 18 else 24))
        }
        contentColumn.addView(roundedLogo(if (tv) 76 else 104, if (tv) 22 else 28),
            LinearLayout.LayoutParams(WRAP, WRAP).apply { bottomMargin = dp(if (tv) 10 else 18) })
        contentColumn.addView(title("اختر طريقة العرض").apply {
            setTextColor(TEXT_MAIN)
            textSize = if (tv) 25f else 23f
            gravity = Gravity.CENTER
        })
        contentColumn.addView(label("حدد الجهاز الذي تستخدمه").apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(if (tv) 14 else 24))
            textSize = if (tv) 13f else 14f
        })

        val choices = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        fun choice(icon: Int, name: String, desc: String, mode: String): View =
            LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(if (tv) 18 else 22), dp(if (tv) 16 else 24),
                    dp(if (tv) 18 else 22), dp(if (tv) 16 else 24))
                addView(ImageView(context).apply {
                    setImageResource(icon)
                    imageTintList = ColorStateList.valueOf(ACCENT)
                    contentDescription = name
                }, LinearLayout.LayoutParams(dp(if (tv) 46 else 58), dp(if (tv) 46 else 58))
                    .apply { bottomMargin = dp(if (tv) 9 else 16) })
                addView(TextView(context).apply {
                    text = name; setTextColor(TEXT_MAIN); textSize = if (tv) 18f else 19f
                    typeface = FONT_MED; gravity = Gravity.CENTER
                })
                addView(TextView(context).apply {
                    text = desc; setTextColor(MUTED); textSize = if (tv) 11f else 12f
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
                makeFocusable(this, 22, CARD, if (tv) 1.045f else 1.06f)
                isClickable = true
                contentDescription = "$name، $desc"
                setOnClickListener {
                    prefs().edit().putString("device_mode", mode).apply()
                    // وضع الهاتف يبقى قابلاً للدوران، بينما واجهة التلفزيون أفقية دائماً.
                    requestedOrientation = if (mode == "tv") ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    showHome()
                }
                pressFx(this)
            }
        val cardWidth = if (tv) 250 else 210
        val cardHeight = if (tv) 150 else 190
        val first = choice(R.drawable.hz_ic_phone, "هاتف أو تابلت", "واجهة اللمس المعتادة", "mobile").apply { id = View.generateViewId() }
        val second = choice(R.drawable.hz_ic_tv, "تلفزيون", "واجهة كبيرة وتحكم بالريموت", "tv").apply { id = View.generateViewId() }
        choices.addView(first, LinearLayout.LayoutParams(dp(cardWidth), dp(cardHeight)).apply { marginEnd = dp(10) })
        choices.addView(second, LinearLayout.LayoutParams(dp(cardWidth), dp(cardHeight)).apply { marginStart = dp(10) })
        first.nextFocusRightId = second.id
        second.nextFocusLeftId = first.id
        contentColumn.addView(choices)
        contentColumn.addView(label("يمكن تغيير الاختيار لاحقاً من الإعدادات").apply {
            gravity = Gravity.CENTER
            textSize = if (tv) 11f else 12f
            setPadding(0, dp(if (tv) 12 else 22), 0, 0)
        })

        val scroller = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(contentColumn, ViewGroup.LayoutParams(MATCH, WRAP))
        }
        show(FrameLayout(this).apply {
            setBackgroundColor(BG)
            addView(scroller, FrameLayout.LayoutParams(MATCH, MATCH))
        }, slide = false)
        if (tv) second.post { second.requestFocus() }
    }

    private fun isTvMode(): Boolean = true // نسخة الشاشات فقط

    private fun showHome() {
        screen = Screen.LIST
        navBack = null
        setFullscreen(false)
        if (!homeAdShown) {
            // AdMob loads asynchronously. Give the first home-screen ad a short
            // window to become ready instead of skipping it immediately.
            if (interstitialAd == null && homeAdWaitAttempts < 10) {
                homeAdWaitAttempts++
                loadInterstitialAd()
                main.postDelayed({
                    if (!isFinishing && !isDestroyed) showHome()
                }, 250)
                return
            }
            homeAdShown = true
            showInterstitialThen { renderHome() }
            return
        }
        renderHome()
    }

    private fun renderHome() {
        if (isTvMode()) { renderTvHome(); return }
        screen = Screen.LIST
        navBack = null
        setFullscreen(false)
        if (prefs().contains("recents")) prefs().edit().remove("recents").apply()
        val c = content
        val chCount = c?.channels.orEmpty().filterNot { isMovieSeriesGroup(it.name) }.sumOf { it.channels.size }
        val fourKCount = fourKChannels(c?.channels.orEmpty()).size
        val serverCount = if (content?.xtream != null) 1 else 0
        val favs = loadList("favs")

        show(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(column().apply {
                addView(homeTopBar(), LinearLayout.LayoutParams(MATCH, WRAP))
                addView(TextView(context).apply {
                    text = "ما الذي تريد\nمشاهدته اليوم؟"
                    setTextColor(TEXT_MAIN); textSize = 28f; typeface = FONT_MED
                    setLineSpacing(0f, 1.15f)
                }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(26); bottomMargin = dp(20) })
                if (chCount > 0) addView(homeCard(R.drawable.hz_ic_tv, "القنوات المباشرة", "$chCount قناة", true) { showGroups("channels") },
                    LinearLayout.LayoutParams(MATCH, dp(150)))
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    addView(homeCard(R.drawable.hz_ic_film, "الأفلام والمسلسلات", if (serverCount > 0) "Xtream" else "غير مضبوط", false) { showMoviesSeriesHub() },
                        LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginEnd = dp(6) })
                    addView(homeCard(R.drawable.hz_ic_4k, "فوركي 4K", "$fourKCount قناة", false) { showFourK() },
                        LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginStart = dp(6) })
                }, LinearLayout.LayoutParams(MATCH, dp(130)).apply { topMargin = if (chCount > 0) dp(12) else 0 })

                addView(homeRow(R.drawable.hz_ic_heart, "المفضلة", "${favs.size}") { showFavorites() },
                    LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
                addView(homeRow(R.drawable.hz_ic_globe, "المتصفح", "", ACCENT) { showBrowser("https://www.google.com") },
                    LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
                addView(telegramFooter(), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(32) })
            })
        })
    }

    // واجهة التلفزيون: تخطيط عريض وبطاقات كبيرة، وكل العناصر قابلة للتركيز بالريموت.
    private fun renderTvHome() {
        screen = Screen.LIST
        navBack = null
        setFullscreen(false)
        val c = content
        val channels = c?.channels.orEmpty().filterNot { isMovieSeriesGroup(it.name) }
        val liveCount = channels.sumOf { it.channels.size }
        val fourCount = fourKChannels(c?.channels.orEmpty()).size
        val servers = movieServers()
        show(FrameLayout(this).apply {
            setPadding(dp(42), dp(26), dp(42), dp(24))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    addView(roundedLogo(54, 16), LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginEnd = dp(16) })
                    addView(LinearLayout(context).apply {
                        orientation = LinearLayout.VERTICAL
                        addView(TextView(context).apply {
                            text = "HORIZON TV"; setTextColor(TEXT_MAIN); textSize = 25f; typeface = Typeface.DEFAULT_BOLD
                        })
                        addView(TextView(context).apply {
                            text = "عالم الترفيه والبث المباشر"; setTextColor(MUTED); textSize = 13f
                        })
                    }, LinearLayout.LayoutParams(0, WRAP, 1f))
                    addView(button("تحديث المحتوى", false) { reloadContent() }, LinearLayout.LayoutParams(dp(170), dp(48)))
                    addView(button("الإعدادات", false) { showTvSettings() },
                        LinearLayout.LayoutParams(dp(140), dp(48)).apply { marginStart = dp(10) })
                })
                addView(TextView(context).apply {
                    text = "اختر وجهتك"; setTextColor(TEXT_MAIN); textSize = 30f; typeface = FONT_MED
                }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(34); bottomMargin = dp(20) })
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER
                    addView(tvHomeCard(R.drawable.hz_ic_4k, "قنوات 4K", "$fourCount قناة", "جودة فائقة", true) { showFourK() },
                        LinearLayout.LayoutParams(0, dp(260), 1f).apply { marginEnd = dp(12) })
                    addView(tvHomeCard(R.drawable.hz_ic_tv, "القنوات المباشرة", "$liveCount قناة", "الباقات والقنوات", false) { showGroups("channels") },
                        LinearLayout.LayoutParams(0, dp(260), 1f).apply { marginHorizontalCompat(dp(12)) })
                    addView(tvHomeCard(R.drawable.hz_ic_film, "الأفلام والمسلسلات", "Xtream", "الأفلام والمسلسلات", false) { showMoviesSeriesHub() },
                        LinearLayout.LayoutParams(0, dp(260), 1f).apply { marginStart = dp(12) })
                }, LinearLayout.LayoutParams(MATCH, WRAP))
                addView(TextView(context).apply {
                    text = "استخدم الأسهم للتنقل و OK للاختيار  •  BACK للرجوع"
                    setTextColor(MUTED); textSize = 13f; gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(22) })
            }, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER))
        })
    }

    private fun LinearLayout.LayoutParams.marginHorizontalCompat(value: Int) = apply {
        leftMargin = value; rightMargin = value
    }

    private fun tvHomeCard(iconRes: Int, name: String, count: String, desc: String, featured: Boolean, click: () -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(if (featured) Color.parseColor("#532A171B") else Color.parseColor("#2920262E"),
                    Color.parseColor("#17191F"))).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), if (featured) Color.parseColor("#99E34B55") else Color.parseColor("#33FFFFFF"))
            }
            addView(ImageView(context).apply {
                setImageResource(iconRes); imageTintList = ColorStateList.valueOf(if (featured) Color.parseColor("#FF6875") else ACCENT)
            }, LinearLayout.LayoutParams(dp(62), dp(62)).apply { bottomMargin = dp(18) })
            addView(TextView(context).apply {
                text = name; setTextColor(TEXT_MAIN); textSize = 22f; typeface = FONT_MED; gravity = Gravity.CENTER
            })
            addView(TextView(context).apply {
                text = count; setTextColor(ACCENT); textSize = 16f; gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(9) })
            addView(TextView(context).apply {
                text = desc; setTextColor(MUTED); textSize = 13f; gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(7) })
            isFocusable = true; isFocusableInTouchMode = false; isClickable = true
            setOnFocusChangeListener { _, focused ->
                animate().scaleX(if (focused) 1.045f else 1f).scaleY(if (focused) 1.045f else 1f)
                    .setDuration(140).start()
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    intArrayOf(if (focused) Color.parseColor("#633B242A") else if (featured) Color.parseColor("#532A171B") else Color.parseColor("#2920262E"),
                        Color.parseColor("#17191F"))).apply {
                    cornerRadius = dp(24).toFloat()
                    setStroke(dp(if (focused) 3 else 1), if (focused) ACCENT else Color.parseColor("#33FFFFFF"))
                }
            }
            setOnClickListener { throttle { click() } }
            pressFx(this)
        }

    private fun showTvSettings() {
        screen = Screen.LIST
        navBack = { showHome() }
        val rows = listOf(
            Row("refresh", "تحديث المحتوى"),
            Row("favs", "المفضلة", listOf("${loadList("favs").size}"))
        )
        showList("إعدادات Horizon", "إعدادات التطبيق", rows, false) { row ->
            when (row.key) {
                "refresh" -> reloadContent()
                "favs" -> showFavorites()
            }
        }
    }

    private fun homeTopBar(): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(roundedLogo(42, 12), LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(12) })
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply {
                text = "Horizon"; setTextColor(TEXT_MAIN); textSize = 20f; typeface = FONT_MED
            })
            addView(TextView(context).apply {
                text = "بث مباشر · أفلام · مسلسلات"; setTextColor(MUTED); textSize = 12f
            })
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        addView(roundButton(R.drawable.hz_ic_refresh, "تحديث المحتوى") { reloadContent() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
    }

    private fun homeCard(iconRes: Int, name: String, sub: String, hero: Boolean, onClick: () -> Unit): View =
        FrameLayout(this).apply {
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(16), dp(18), dp(16))
                addView(ImageView(context).apply {
                    setImageResource(iconRes)
                    imageTintList = ColorStateList.valueOf(ACCENT)
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                    background = surface(14, ACCENT_SOFT, Color.TRANSPARENT, 0)
                }, LinearLayout.LayoutParams(dp(46), dp(46)))
                addView(View(context), LinearLayout.LayoutParams(MATCH, 0, 1f))
                addView(TextView(context).apply {
                    text = name; setTextColor(TEXT_MAIN); typeface = FONT_MED
                    textSize = if (hero) 20f else 15f; maxLines = 2
                })
                addView(TextView(context).apply {
                    text = sub; setTextColor(MUTED); textSize = 12f; setPadding(0, dp(3), 0, 0)
                })
            }, FrameLayout.LayoutParams(MATCH, MATCH))
            if (hero) addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(View(context).apply {
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(DANGER) }
                }, LinearLayout.LayoutParams(dp(7), dp(7)).apply { marginEnd = dp(6) })
                addView(TextView(context).apply {
                    text = "مباشر"; setTextColor(DANGER); textSize = 11f; typeface = FONT_MED
                })
            }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(20), dp(20), 0) })
            makeFocusable(this, 22, CARD, 1.03f)
            isClickable = true
            setOnClickListener { throttle { onClick() } }
            pressFx(this)
        }

    private fun homeRow(iconRes: Int, name: String, count: String, tint: Int = DANGER, onClick: () -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(16), dp(16), dp(16))
            addView(ImageView(context).apply {
                setImageResource(iconRes); imageTintList = ColorStateList.valueOf(tint)
            }, LinearLayout.LayoutParams(dp(22), dp(22)))
            addView(TextView(context).apply {
                text = name; setTextColor(TEXT_MAIN); textSize = 16f; typeface = FONT_MED
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14) })
            if (count.isNotEmpty()) addView(TextView(context).apply { text = count; setTextColor(MUTED); textSize = 14f })
            addView(ImageView(context).apply {
                setImageResource(R.drawable.hz_ic_chevron); imageTintList = ColorStateList.valueOf(MUTED)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(10) })
            makeFocusable(this, 18, CARD, 1.02f)
            isClickable = true
            setOnClickListener { throttle { onClick() } }
            pressFx(this)
        }

    private fun telegramFooter(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(12), dp(22), dp(12))
            addView(ImageView(context).apply {
                setImageResource(R.drawable.hz_ic_telegram)
                imageTintList = ColorStateList.valueOf(Color.parseColor("#4FB6EC"))
            }, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(10) })
            addView(TextView(context).apply {
                text = "قناتنا على تليجرام"; setTextColor(TEXT_MAIN); textSize = 13f; typeface = FONT_MED
            })
            makeFocusable(this, 24, CARD, 1.04f)
            isClickable = true
            setOnClickListener { throttle { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(telegramUrl))) } }
            pressFx(this)
        }, LinearLayout.LayoutParams(WRAP, WRAP))
        addView(TextView(context).apply {
            text = "جميع الحقوق محفوظة لدى قناة HorizonTV"
            setTextColor(MUTED); textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(10))
        }, LinearLayout.LayoutParams(WRAP, WRAP))
    }



    // ================= المتصفح الداخلي =================

    private fun destroyWebView() {
        hideCustomView()
        webView?.let { w ->
            try {
                w.stopLoading()
                w.loadUrl("about:blank")
                (w.parent as? ViewGroup)?.removeView(w)
                w.destroy()
            } catch (_: Throwable) {}
        }
        webView = null
        tvCursor = null
        browserTopBar = null
    }

    private fun hideCustomView() {
        val v = customView ?: return
        root.removeView(v)
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        setFullscreen(false)
    }

    /** يحوّل ما كتبه المستخدم إلى رابط أو بحث Google. */
    private fun normalizeBrowserInput(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) return "https://www.google.com"
        val low = t.lowercase()
        if (low.startsWith("http://") || low.startsWith("https://")) return t
        if (!t.contains(' ') && t.contains('.')) return "https://$t"
        return "https://www.google.com/search?q=" + Uri.encode(t)
    }

    /** يبقى http/https داخل المتصفح؛ الروابط الأخرى تُفتح خارجياً، وfile/javascript محجوبة. */
    private fun handleBrowserUrl(url: String): Boolean {
        val low = url.lowercase()
        if (low.startsWith("http://") || low.startsWith("https://") || low.startsWith("about:")) return false
        if (low.startsWith("file:") || low.startsWith("javascript:") || low.startsWith("content:")) return true
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Throwable) {}
        return true
    }

    private fun showBrowser(startUrl: String, back: () -> Unit = { showHome() }) {
        screen = Screen.LIST
        navBack = back
        setFullscreen(false)

        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(ACCENT)
            visibility = View.GONE
        }
        val urlField = EditText(this).apply {
            hint = "ابحث أو اكتب رابطاً"
            setHintTextColor(MUTED)
            setTextColor(TEXT_MAIN)
            setSingleLine()
            textSize = 14f
            setPadding(dp(16), 0, dp(16), 0)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            background = surface(14, CARD)
        }
        val wv = WebView(this).apply {
            setBackgroundColor(Color.WHITE)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = false
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                mediaPlaybackRequiresUserGesture = false
                loadWithOverviewMode = true
                useWideViewPort = true
                builtInZoomControls = true
                displayZoomControls = false
                setSupportMultipleWindows(false)
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                    handleBrowserUrl(request.url.toString())
                @Suppress("OVERRIDE_DEPRECATION", "DEPRECATION")
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = handleBrowserUrl(url)
                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                    progress.visibility = View.VISIBLE
                    if (url != null && !urlField.hasFocus()) urlField.setText(url)
                }
                override fun onPageFinished(view: WebView, url: String?) {
                    progress.visibility = View.GONE
                    if (url != null && !urlField.hasFocus()) urlField.setText(url)
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
                }
                override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                    if (customView != null) { callback.onCustomViewHidden(); return }
                    customView = view
                    customCb = callback
                    root.addView(view, MATCH, MATCH)
                    setFullscreen(true)
                }
                override fun onHideCustomView() { hideCustomView() }
            }
        }
        val go = {
            wv.loadUrl(normalizeBrowserInput(urlField.text.toString()))
            urlField.clearFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .hideSoftInputFromWindow(urlField.windowToken, 0)
        }
        urlField.setOnEditorActionListener { _, actionId, event ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_GO ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                go(); true
            } else false
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(roundButton(R.drawable.hz_ic_close, "إغلاق المتصفح") { back() },
                LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(10) })
            addView(urlField, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            fun slot() = LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(6), 0, dp(6), 0) }
            addView(roundButton(R.drawable.hz_ic_back, "للخلف") { if (wv.canGoBack()) wv.goBack() }, slot())
            addView(roundButton(R.drawable.hz_ic_chevron, "للأمام") { if (wv.canGoForward()) wv.goForward() }, slot())
            addView(roundButton(R.drawable.hz_ic_refresh, "تحديث الصفحة") { wv.reload() }, slot())
            addView(roundButton(R.drawable.hz_ic_home, "الصفحة الرئيسية") { wv.loadUrl("https://www.google.com") }, slot())
        }

        val tvBrowser = isTvMode()
        val webArea = FrameLayout(this)
        webArea.addView(wv, FrameLayout.LayoutParams(MATCH, MATCH))
        val cur = ImageView(this).apply {
            background = cursorDrawable()
            isFocusable = false
        }
        if (tvBrowser) webArea.addView(cur, FrameLayout.LayoutParams(dp(26), dp(26)))
        show(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(24), 0, 0)
            addView(topBar, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(progress, LinearLayout.LayoutParams(MATCH, dp(3)))
            addView(webArea, LinearLayout.LayoutParams(MATCH, 0, 1f))
            if (!tvBrowser) addView(bottomBar, LinearLayout.LayoutParams(MATCH, WRAP))
        })
        webView = wv
        if (tvBrowser) {
            tvCursor = cur
            browserTopBar = topBar
            cursorMode = true
            webArea.post {
                cursorX = webArea.width / 2f
                cursorY = webArea.height / 2f
                placeCursor()
                wv.isFocusable = true
                wv.requestFocus()
            }
            Toast.makeText(this, "الأسهم تحرّك المؤشر · OK للنقر · زر القائمة لتبديل الوضع", Toast.LENGTH_LONG).show()
        }
        wv.loadUrl(normalizeBrowserInput(startUrl))
    }

    private val defaultServers = emptyList<M3uSource>()

    /** الأفلام والمسلسلات تأتي من Xtream، بينما القنوات المباشرة تبقى من content.json. */
    private fun movieServers(): List<M3uSource> = content?.servers.orEmpty()

    private fun showMoviesSeriesHub() {
        if (isTvMode()) { showTvVOD(); return }
        val xt = content?.xtream
        screen = Screen.LIST
        navBack = { showHome() }
        setFullscreen(false)
        val rows = buildList {
            if (xt != null) {
                add(Row("movies", "الأفلام", listOf("Xtream")))
                add(Row("series", "المسلسلات", listOf("Xtream")))
            }
            if (content?.series.orEmpty().isNotEmpty())
                add(Row("local_series", "ليل البنفسج", listOf("الموسم الثاني")))
            if (isEmpty()) add(Row("__e", "لا يوجد مصدر أفلام ومسلسلات"))
        }
        showList("الأفلام والمسلسلات", "اختر القسم", rows, true) { row ->
            when (row.key) {
                "movies" -> xt?.let { loadXtreamMovies(it) }
                "series" -> xt?.let { loadXtreamSeries(it) }
                "local_series" -> showSeriesGroups()
            }
        }
    }

    private fun loadXtreamMovies(xt: XtreamConfig) {
        showLoading("جارٍ تحميل الأفلام من Xtream...")
        XtreamRepository.movies(xt) { result ->
            runOnUiThread {
                result.onSuccess { groups -> showXtreamMovieGroups(xt, groups) }
                    .onFailure { err -> showError("تعذّر تحميل الأفلام من Xtream", err.message.orEmpty()) { loadXtreamMovies(xt) } }
            }
        }
    }

    private fun showXtreamMovieGroups(xt: XtreamConfig, groups: List<Pair<String, List<XtreamMovie>>>) {
        screen = Screen.LIST
        navBack = { showMoviesSeriesHub() }
        setFullscreen(false)
        val rows = groups.mapIndexed { i, g -> Row("g:$i", g.first, listOf("${g.second.size}")) }
        showList("الأفلام", "تصنيفات Xtream", rows, true) { row ->
            val i = row.key.removePrefix("g:").toIntOrNull() ?: return@showList
            val g = groups.getOrNull(i) ?: return@showList
            val items = g.second.map { m ->
                Channel(m.name, mapOf("VOD" to XtreamRepository.movieUrl(xt, m.streamId, m.extension)), m.logo)
            }
            val reopen: () -> Unit = { showXtreamMovieGroups(xt, groups) }
            showPosterGrid(g.first, items, reopen) { _, ch -> startPlayback(ch, g.first, items, g.first, reopen, null) }
        }
    }

    private fun loadXtreamSeries(xt: XtreamConfig) {
        showLoading("جارٍ تحميل المسلسلات من Xtream...")
        XtreamRepository.series(xt) { result ->
            runOnUiThread {
                result.onSuccess { groups -> showXtreamSeriesGroups(xt, groups) }
                    .onFailure { err -> showError("تعذّر تحميل المسلسلات من Xtream", err.message.orEmpty()) { loadXtreamSeries(xt) } }
            }
        }
    }

    private fun showXtreamSeriesGroups(xt: XtreamConfig, groups: List<Pair<String, List<XtreamSeriesItem>>>) {
        screen = Screen.LIST
        navBack = { showMoviesSeriesHub() }
        setFullscreen(false)
        val rows = groups.mapIndexed { i, g -> Row("g:$i", g.first, listOf("${g.second.size}")) }
        showList("المسلسلات", "تصنيفات Xtream", rows, true) { row ->
            val i = row.key.removePrefix("g:").toIntOrNull() ?: return@showList
            val g = groups.getOrNull(i) ?: return@showList
            showXtreamSeriesList(xt, g.first, g.second, { showXtreamSeriesGroups(xt, groups) })
        }
    }

    private fun showXtreamSeriesList(xt: XtreamConfig, category: String, items: List<XtreamSeriesItem>, back: () -> Unit) {
        screen = Screen.LIST
        navBack = back
        setFullscreen(false)
        val posters = items.map { Channel(it.name, emptyMap(), it.logo) }
        showPosterGrid(category, posters, back) { i, _ ->
            val s = items.getOrNull(i) ?: return@showPosterGrid
            showLoading("جارٍ تحميل حلقات ${s.name}...")
            XtreamRepository.episodes(xt, s.seriesId) { result ->
                runOnUiThread {
                    result.onSuccess { seasons -> showXtreamEpisodes(xt, s.name, seasons, { showXtreamSeriesList(xt, category, items, back) }) }
                        .onFailure { err -> showError("تعذّر تحميل حلقات المسلسل", err.message.orEmpty()) { showXtreamSeriesList(xt, category, items, back) } }
                }
            }
        }
    }

    private fun showXtreamEpisodes(xt: XtreamConfig, title: String, seasons: List<Pair<String, List<XtreamEpisode>>>, back: () -> Unit) {
        val flat = ArrayList<Channel>()
        val headers = HashMap<Int, String>()
        seasons.forEach { (season, eps) ->
            headers[flat.size] = season
            eps.forEach { e ->
                flat.add(Channel(e.name, mapOf("VOD" to XtreamRepository.episodeUrl(xt, e.episodeId, e.extension)), e.logo))
            }
        }
        showItems(title, flat, title, headers, back, null, null)
    }

    // ---- فوركي 4K ----

    private val FOURK_SUB = "4K"
    private var fourKMode = false
    private fun is4KKey(k: String) = k.equals("4K", true) || k.equals("UHD", true)
    private fun has4K(ch: Channel) =
        ch.streams.keys.any { is4KKey(it) } || ch.name.contains("4K", true) || ch.name.contains("UHD", true)
    private val fourKBrand = Regex("(bein|bien|be\\s*in|بي\\s*ان|بى\\s*ان|بين\\s*سبورت|الوان|ألوان|alwan)", RegexOption.IGNORE_CASE)
    private val movieGroupRegex = Regex("(فيلم|أفلام|افلام|مسلسل|movie|series|film)", RegexOption.IGNORE_CASE)
    private fun isMovieSeriesGroup(name: String) = movieGroupRegex.containsMatchIn(name)

    /** أي قناة فيها جودة 4K وتنتمي لـ beIN أو ألوان سبورت (باسم القناة أو اسم قسمها) من أي قسم. */
    private fun fourKChannels(groups: List<Group>): List<Channel> =
        groups.filterNot { isMovieSeriesGroup(it.name) }
            .flatMap { g ->
                g.channels.filter { has4K(it) && (fourKBrand.containsMatchIn(it.name) || fourKBrand.containsMatchIn(g.name)) }
            }
            .distinctBy { it.name.lowercase() + "|" + it.streams.values.firstOrNull().orEmpty() }

    private fun showFourK() {
        val items = fourKChannels(content?.channels.orEmpty())
        if (items.isEmpty()) {
            screen = Screen.LIST
            navBack = { showHome() }
            setFullscreen(false)
            showList("فوركي 4K", "0 قناة", listOf(Row("__e", "لا توجد قنوات 4K حالياً")), false) { }
            return
        }
        showChannelGrid("فوركي 4K", items, FOURK_SUB, { showHome() }, null, null)
    }

    private fun channelKey(ch: Channel): String {
        val url = ch.streams.values.firstOrNull()?.trim().orEmpty()
        return if (url.isNotEmpty()) url else ch.name.trim().lowercase(Locale.ROOT)
    }

    /** يحدّث content.json من GitHub، يعرض القنوات الجديدة، ثم يعيد فتح نفس القسم. */
    private fun refreshContent(titleText: String, sub: String, back: () -> Unit) {
        val oldKeys = content?.channels.orEmpty().flatMap { it.channels }.map { channelKey(it) }.toSet()
        showLoading("جارٍ تحديث القنوات...")
        ChannelRepository.load(this) { fresh ->
            reportSource()
            if (fresh != null) {
                content = fresh
                prefetchOverlays(fresh)
                applySecurity(fresh)
                pruneFavorites(fresh)
                val added = fresh.channels.filterNot { isMovieSeriesGroup(it.name) }
                    .flatMap { it.channels }.filter { channelKey(it) !in oldKeys }
                if (added.isNotEmpty()) showNewChannelsDialog(added, fresh.channels.sumOf { it.channels.size })
            }
            if (sub == FOURK_SUB) { showFourK(); return@load }
            val g = content?.channels?.firstOrNull { it.name == titleText }
            if (g != null) showChannelGrid(g.name, g.channels, g.name, back, content?.channels, null)
            else showGroups("channels")
        }
    }

    private fun showNewChannelsDialog(newChannels: List<Channel>, totalCount: Int) {
        val names = newChannels.take(30).joinToString("\n") { "• ${it.name}" }
        val extra = if (newChannels.size > 30) "\n… و ${newChannels.size - 30} قناة أخرى" else ""
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("${newChannels.size} قناة جديدة")
            .setMessage("$names$extra\n\nإجمالي القنوات الآن: $totalCount")
            .setPositiveButton("حسناً", null)
            .show()
    }

    private fun showGroups(kind: String) {
        if (isTvMode() && kind == "channels") { showTvLive(); return }
        screen = Screen.LIST
        navBack = if (kind == "channels") ({ showHome() }) else ({ showMoviesSeriesHub() })
        setFullscreen(false)
        val groups = ((if (kind == "channels") content?.channels else content?.movies) ?: emptyList())
            .filter { kind != "channels" || !isMovieSeriesGroup(it.name) }
        val m3uSources = if (kind == "channels") content?.m3uSources.orEmpty() else emptyList()
        val rows = ArrayList<Row>()
        groups.forEachIndexed { i, g -> rows.add(Row("g:$i", g.name, listOf("${g.channels.size}"))) }
        if (m3uSources.isNotEmpty()) {
            rows.add(Row("__m3u", "مصادر خارجية"))
            m3uSources.forEachIndexed { i, src -> rows.add(Row("m:$i", "📡  ${src.name}", listOf("مباشر"))) }
        }
        val reopen: () -> Unit = { showGroups(kind) }
        showList(if (kind == "channels") "القنوات" else "الأفلام", "اختر القسم", rows, true) { row ->
            when {
                row.key.startsWith("g:") -> {
                    val g = groups.getOrNull(row.key.removePrefix("g:").toIntOrNull() ?: -1)
                    if (g == null) return@showList
                    if (kind == "channels")
                        showChannelGrid(g.name, g.channels, g.name, reopen, groups, null)
                    else
                        showItems(g.name, g.channels, g.name, emptyMap(), reopen, null, null)
                }
                row.key.startsWith("m:") -> {
                    val src = m3uSources.getOrNull(row.key.removePrefix("m:").toIntOrNull() ?: -1)
                    if (src != null) fetchM3u(src, reopen)
                }
            }
        }
    }

    /** يجلب قائمة تشغيل M3U خارجية ويعرض أقسامها، بنفس أسلوب تصفح القنوات العادي. */
    private fun fetchM3u(src: M3uSource, back: () -> Unit) {
        val token = ++loadToken
        navBack = back
        showLoading("جارٍ تحميل ${src.name}...")
        M3uParser.async({ M3uParser.fetchGroups(src.url) }) { r ->
            if (token != loadToken) return@async
            r.onSuccess { groups ->
                if (groups.isEmpty()) showError("القائمة فارغة حالياً") { fetchM3u(src, back) }
                else showGroupList(src.name, groups, back)
            }.onFailure { showError("تعذّر تحميل ${src.name}") { fetchM3u(src, back) } }
        }
    }

    /** تصفّح عام لأقسام قد تأتي من مصدر خارجي (M3U) وليس من content.json مباشرة. */
    private fun showGroupList(titleText: String, groups: List<Group>, back: () -> Unit) {
        screen = Screen.LIST
        navBack = back
        setFullscreen(false)
        val rows = groups.mapIndexed { i, g -> Row("g:$i", g.name, listOf("${g.channels.size}")) }
        val reopen: () -> Unit = { showGroupList(titleText, groups, back) }
        showList(titleText, "اختر القسم", rows, true) { row ->
            val g = groups.getOrNull(row.key.removePrefix("g:").toIntOrNull() ?: -1)
            if (g != null) showChannelGrid(g.name, g.channels, g.name, reopen, groups, null)
        }
    }

    /** عرض القنوات كمربعات شعار، كل مربع يحمل صورة القناة من ملف المحتوى (logo) واسمها. */
    private fun showChannelGrid(
        titleText: String, items: List<Channel>, sub: String,
        back: () -> Unit, groups: List<Group>?, refresh: (() -> Unit)?
    ) {
        screen = Screen.LIST
        setFullscreen(false)
        navBack = back
        val favUrls = loadList("favs").map { firstUrl(it) }.toSet()
        var shown = items
        val reopen: () -> Unit = { showChannelGrid(titleText, items, sub, back, groups, refresh) }

        lateinit var grid: GridView
        fun bind() {
            grid.adapter = object : BaseAdapter() {
                override fun getCount() = shown.size
                override fun getItem(p: Int) = shown[p]
                override fun getItemId(p: Int) = p.toLong()
                override fun getView(p: Int, cv: View?, g: ViewGroup): View {
                    val ch = shown[p]
                    val fav = ch.streams.values.firstOrNull() in favUrls
                    return channelTile(ch, fav, p + 1,
                        onClick = { startPlayback(ch, sub, items, titleText, reopen, groups) },
                        onLongClick = {
                            val added = toggleFav(Entry(ch.name, sub, ch.streams))
                            toast(if (added) "أُضيف إلى المفضلة ♥" else "أُزيل من المفضلة")
                            (refresh ?: reopen)()
                        })
                }
            }
        }
        grid = GridView(this).apply {
            numColumns = gridColumns()
            verticalSpacing = dp(10)
            horizontalSpacing = dp(10)
            clipToPadding = false
            setPadding(0, 0, 0, dp(24))
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
        }
        bind()
        activeAdapterView = grid
        grid.isFocusable = true
        grid.isFocusableInTouchMode = false

        show(column().apply {
            addView(header(titleText, "${items.size} · اضغط مطولاً للمفضلة"), LinearLayout.LayoutParams(MATCH, WRAP))
            val search = searchField { q ->
                shown = if (q.isEmpty()) items else items.filter { it.name.contains(q, true) }
                bind()
            }
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(search, LinearLayout.LayoutParams(0, MATCH, 1f))
                addView(roundButton(R.drawable.hz_ic_refresh, "تحديث القنوات") { refreshContent(titleText, sub, back) },
                    LinearLayout.LayoutParams(dp(50), dp(50)).apply { marginStart = dp(10) })
            }, LinearLayout.LayoutParams(MATCH, dp(50)).apply { bottomMargin = dp(14) })
            addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        })
        grid.post { if (grid.count > 0) { grid.setSelection(0); grid.requestFocus() } }
    }

    /** مربع قناة واحد: شعارها من الرابط الموجود في ملف المحتوى، واسمها تحته. */
    private fun channelTile(ch: Channel, isFav: Boolean, number: Int, onClick: () -> Unit, onLongClick: () -> Unit): View {
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        val hasLogo = ch.logo.isNotBlank()
        if (hasLogo) ImageLoader.load(ch.logo, img)
        val nameTv = TextView(this).apply {
            text = ch.name
            setTextColor(TEXT_MAIN); textSize = 11.5f; typeface = FONT_MED
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(6), dp(2), dp(6), dp(10))
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(FrameLayout(context).apply {
                addView(img, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER))
                if (!hasLogo) addView(TextView(context).apply {
                    text = number.toString(); setTextColor(ACCENT); textSize = 18f; typeface = FONT_MED
                    gravity = Gravity.CENTER
                    background = surface(16, ACCENT_SOFT, Color.TRANSPARENT, 0)
                }, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER))
                if (isFav) addView(ImageView(context).apply {
                    setImageResource(R.drawable.hz_ic_heart); imageTintList = ColorStateList.valueOf(DANGER)
                }, FrameLayout.LayoutParams(dp(14), dp(14), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(2), dp(8), 0) })
            }, LinearLayout.LayoutParams(MATCH, dp(74)).apply { topMargin = dp(8) })
            addView(nameTv, LinearLayout.LayoutParams(MATCH, WRAP))
            makeFocusable(this, 18, CARD, 1.05f)
            isClickable = true
            setOnClickListener { throttle { onClick() } }
            setOnLongClickListener {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                throttle { onLongClick() }; true
            }
            pressFx(this)
        }
    }

    /** شبكة بوسترات للأفلام والمسلسلات: صورة الغلاف من الرابط وتحتها الاسم، مع بحث. */
    private fun showPosterGrid(
        titleText: String, items: List<Channel>, back: () -> Unit,
        onClick: (Int, Channel) -> Unit
    ) {
        screen = Screen.LIST
        setFullscreen(false)
        navBack = back
        var shown = items
        lateinit var grid: GridView
        fun bind() {
            grid.adapter = object : BaseAdapter() {
                override fun getCount() = shown.size
                override fun getItem(p: Int) = shown[p]
                override fun getItemId(p: Int) = p.toLong()
                override fun getView(p: Int, cv: View?, g: ViewGroup): View {
                    val ch = shown[p]
                    return posterTile(ch) { onClick(items.indexOfFirst { it === ch }, ch) }
                }
            }
        }
        grid = GridView(this).apply {
            numColumns = gridColumns()
            verticalSpacing = dp(12)
            horizontalSpacing = dp(10)
            clipToPadding = false
            setPadding(0, 0, 0, dp(24))
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
        }
        bind()
        activeAdapterView = grid
        grid.isFocusable = true
        grid.isFocusableInTouchMode = false
        show(column().apply {
            addView(header(titleText, "${items.size}"), LinearLayout.LayoutParams(MATCH, WRAP))
            val search = searchField { q ->
                shown = if (q.isEmpty()) items else items.filter { it.name.contains(q, true) }
                bind()
            }
            addView(search, LinearLayout.LayoutParams(MATCH, dp(50)).apply { bottomMargin = dp(14) })
            addView(grid, LinearLayout.LayoutParams(MATCH, 0, 1f))
        })
        grid.post { if (grid.count > 0) { grid.setSelection(0); grid.requestFocus() } }
    }

    private fun posterTile(ch: Channel, onClick: () -> Unit): View {
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = surface(14, CARD, Color.TRANSPARENT, 0)
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, dp(14).toFloat())
                }
            }
        }
        if (ch.logo.isNotBlank()) ImageLoader.load(ch.logo, img)
        val nameTv = TextView(this).apply {
            text = ch.name
            setTextColor(TEXT_MAIN); textSize = 12f; typeface = FONT_MED
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(4), dp(6), dp(4), dp(8))
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = AbsListView.LayoutParams(MATCH, dp(if (isTvMode()) 270 else 235))
            setPadding(dp(4), dp(4), dp(4), 0)
            addView(img, LinearLayout.LayoutParams(MATCH, 0, 1f))
            addView(nameTv, LinearLayout.LayoutParams(MATCH, WRAP))
            makeFocusable(this, 16, CARD, 1.05f)
            isClickable = true
            setOnClickListener { throttle { onClick() } }
            pressFx(this)
        }
    }

    private fun showFavorites() {
        val items = loadList("favs").map { Channel(it.title, it.streams) }
        showItems("المفضلة", items, "", emptyMap(), { showHome() }, null) { showFavorites() }
    }

    /** قائمة عناصر قابلة للتشغيل (قنوات / أفلام / حلقات / مفضلة). */
    private fun showItems(
        titleText: String, items: List<Channel>, sub: String, headers: Map<Int, String>,
        back: () -> Unit, groups: List<Group>?, refresh: (() -> Unit)?
    ) {
        screen = Screen.LIST
        setFullscreen(false)
        navBack = back
        val favUrls = loadList("favs").map { firstUrl(it) }.toSet()
        val rows = ArrayList<Row>()
        items.forEachIndexed { i, ch ->
            headers[i]?.let { rows.add(Row("__h$i", it)) }
            val fav = ch.streams.values.firstOrNull() in favUrls
            rows.add(Row("i:$i", ch.name, trailing = if (fav) "♥" else "♡", isFavorite = fav))
        }
        val reopen: () -> Unit = { showItems(titleText, items, sub, headers, back, groups, refresh) }
        showList(titleText, "${items.size} · اضغط مطولاً للمفضلة", rows, true,
            onLongClick = { row ->
                val ch = items.getOrNull(row.key.removePrefix("i:").toIntOrNull() ?: -1)
                if (ch != null) {
                    val added = toggleFav(Entry(ch.name, sub, ch.streams))
                    toast(if (added) "أُضيف إلى المفضلة ♥" else "أُزيل من المفضلة")
                    (refresh ?: reopen)()
                }
            },
            onClick = { row ->
                val ch = items.getOrNull(row.key.removePrefix("i:").toIntOrNull() ?: -1)
                if (ch != null) startPlayback(ch, sub, items, titleText, reopen, groups)
            })
    }

    // ---- المسلسلات ----

    private fun showSeriesGroups() {
        screen = Screen.LIST
        navBack = { showMoviesSeriesHub() }
        setFullscreen(false)
        val groups = content?.series ?: emptyList()
        val rows = groups.mapIndexed { i, g -> Row("g:$i", g.name, listOf("${g.items.size}")) }
        val reopen: () -> Unit = { showSeriesGroups() }
        showList("المسلسلات", "اختر القسم", rows, true) { row ->
            val g = groups.getOrNull(row.key.removePrefix("g:").toIntOrNull() ?: -1)
            if (g != null) showSeriesList(g, reopen)
        }
    }

    private fun showSeriesList(g: SeriesGroup, back: () -> Unit) {
        screen = Screen.LIST
        navBack = back
        val rows = g.items.mapIndexed { i, s -> Row("s:$i", s.name, listOf("${s.seasons.size} موسم")) }
        val reopen: () -> Unit = { showSeriesList(g, back) }
        showList(g.name, "${g.items.size} مسلسل", rows, true) { row ->
            val s = g.items.getOrNull(row.key.removePrefix("s:").toIntOrNull() ?: -1)
            if (s != null) {
                val flat = ArrayList<Channel>()
                val headers = HashMap<Int, String>()
                s.seasons.forEach { (seasonName, eps) -> headers[flat.size] = seasonName; flat.addAll(eps) }
                showItems(s.name, flat, s.name, headers, reopen, null, null)
            }
        }
    }

    // ---- مباريات اليوم ----

    private fun initializeAdMob() {
        MobileAds.initialize(this) { runOnUiThread { loadInterstitialAd() } }
    }

    private fun loadInterstitialAd() {
        if (isAdLoading || interstitialAd != null) return
        isAdLoading = true
        val unitId = if (useTestAd) admobTestInterstitialId else admobInterstitialId
        InterstitialAd.load(this, unitId, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) {
                isAdLoading = false
                interstitialAd = ad
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() { interstitialAd = null; loadInterstitialAd() }
                    override fun onAdFailedToShowFullScreenContent(e: com.google.android.gms.ads.AdError) { Log.e("HorizonTV-AdMob", "show failed: ${e.code} ${e.message}"); interstitialAd = null; loadInterstitialAd() }
                }
            }
            override fun onAdFailedToLoad(e: LoadAdError) {
                isAdLoading = false; interstitialAd = null
                Log.e("HorizonTV-AdMob", "load failed: ${e.code} ${e.message}")
                main.postDelayed({ loadInterstitialAd() }, 10000)
            }
        })
    }

    private fun showInterstitialThen(action: () -> Unit) {
        val ad = interstitialAd
        if (ad == null) { loadInterstitialAd(); action(); return }
        interstitialAd = null
        var continued = false
        fun continueOnce() { if (!continued) { continued = true; action() } }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { loadInterstitialAd(); continueOnce() }
            override fun onAdFailedToShowFullScreenContent(e: com.google.android.gms.ads.AdError) { Log.e("HorizonTV-AdMob", "show failed: ${e.code} ${e.message}"); loadInterstitialAd(); continueOnce() }
        }
        ad.show(this)
    }

    // ================= Player =================

    private fun startPlayback(
        ch: Channel, sub: String, list: List<Channel>, title: String,
        back: () -> Unit, groups: List<Group>?
    ) {
        playlist = list
        playlistTitle = title
        playerBack = back
        panelGroups = groups
        panelShowGroups = false
        fourKMode = (sub == FOURK_SUB)
        showInterstitialThen { play(ch, sub) }
    }

    /** يفتح القناة. إن كان المشغّل مفتوحاً أصلاً يبدّل البث فقط (يمنع الانهيار). */
    private fun play(ch: Channel, sub: String, quality: String? = null) {
        val q = quality
            ?: (if (fourKMode) ch.streams.keys.firstOrNull { is4KKey(it) } else null)
            ?: ch.streams.keys.firstOrNull() ?: run {
            toast("لا يوجد رابط تشغيل"); return
        }
        if (screen != Screen.PLAYER) buildPlayerScreen()
        screen = Screen.PLAYER
        curSub = sub
        startStream(ch, sub, q)
    }

    private fun buildPlayerScreen() {
        stopPlayer()
        playerView = PlayerView(this).apply {
            keepScreenOn = true
            useController = false
            isFocusable = false
            isFocusableInTouchMode = false
            resizeMode = resizeModes[resizeIndex]
            setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER) // لدينا مؤشر تحميل خاص بنا
        }
        qualityBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setBackgroundColor(Color.parseColor("#F20A0B0F"))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        // ---- شارة "مباشر" + اسم القناة ----
        liveDot = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(DANGER) }
        }
        val liveBadge = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(liveDot, LinearLayout.LayoutParams(dp(7), dp(7)).apply { marginEnd = dp(5) })
            addView(TextView(context).apply {
                text = "مباشر"; setTextColor(DANGER); textSize = 10f; typeface = Typeface.DEFAULT_BOLD
            })
        }
        pulse(liveDot)
        infoName = TextView(this).apply {
            setTextColor(TEXT_MAIN); textSize = 17f; typeface = Typeface.DEFAULT_BOLD
        }
        infoCat = TextView(this).apply { setTextColor(MUTED); textSize = 12f }
        infoCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#B3000000"))
                setStroke(dp(1), BORDER)
            }
            addView(liveBadge, LinearLayout.LayoutParams(WRAP, WRAP).apply { bottomMargin = dp(4) })
            addView(infoName)
            addView(infoCat)
        }

        // ---- مؤشر تحميل مركزي ----
        buffSpinner = ProgressBar(this).apply {
            indeterminateTintList = ColorStateList.valueOf(ACCENT)
            visibility = View.GONE
        }

        // ---- واجهة المشغّل الجديدة: أزرار علوية، شريط تقدّم، وصف تحكم سفلي ----
        playPauseChip = iconButton(R.drawable.hz_ic_pause, "تشغيل أو إيقاف مؤقت", 30, 66, true) { togglePlayPause() }
        muteChip = iconButton(R.drawable.hz_ic_volume, "كتم أو تشغيل الصوت", 26, 46) { toggleMute() }
        val ccBtn = iconButton(R.drawable.hz_ic_cc, "الجودة والصوت والترجمة", 28, 46) { showPlayerSettings() }
        lockBtn = iconButton(R.drawable.hz_ic_unlock, "قفل الشاشة", 26, 46) {
            controlsLocked = !controlsLocked
            applyLock()
            toast(if (controlsLocked) "الشاشة مقفلة" else "تم فتح القفل")
        }
        val speedBtn = iconButton(R.drawable.hz_ic_speed, "سرعة التشغيل", 28, 46) { cycleSpeed() }
        val prevBtn = iconButton(R.drawable.hz_ic_prev, "القناة السابقة", 26, 46) { stepChannel(-1) }
        val nextBtn = iconButton(R.drawable.hz_ic_next, "القناة التالية", 26, 46) { stepChannel(1) }
        val back5 = seekButton(R.drawable.hz_ic_replay, "رجوع 5 ثوانٍ") { seekBy(-5_000L) }
        val fwd5 = seekButton(R.drawable.hz_ic_forward, "تقديم 5 ثوانٍ") { seekBy(5_000L) }

        // أزرار الصف العلوي
        val menuChip = chip("القائمة", true) { togglePanel() }
        val extChip = chip("صوت قناة أخرى", false) { showExtAudioPicker() }
        val statChip = chip("إحصائيات", false) { toggleStats() }
        extChipView = extChip
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(menuChip, LinearLayout.LayoutParams(WRAP, dp(38)).apply { marginEnd = dp(8) })
            addView(extChip, LinearLayout.LayoutParams(WRAP, dp(38)).apply { marginEnd = dp(8) })
            addView(statChip, LinearLayout.LayoutParams(WRAP, dp(38)).apply { marginEnd = dp(14) })
            addView(iconButton(R.drawable.hz_ic_camera, "لقطة شاشة", 26, 46) { takeScreenshot() },
                LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(8) })
            addView(iconButton(R.drawable.hz_ic_pip, "صورة داخل صورة", 26, 46) { enterPip() },
                LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(8) })
            addView(iconButton(R.drawable.hz_ic_aspect, "أبعاد الصورة", 26, 46) {
                resizeIndex = (resizeIndex + 1) % resizeModes.size
                playerView.resizeMode = resizeModes[resizeIndex]
                showControls()
            }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(8) })
            addView(iconButton(R.drawable.hz_ic_rotate, "تدوير الشاشة", 26, 46) { rotateScreen() },
                LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(8) })
            addView(iconButton(R.drawable.hz_ic_close, "إغلاق", 26, 46) { leavePlayer() },
                LinearLayout.LayoutParams(dp(46), dp(46)))
        }

        // شريط التقدّم (للأفلام والمحتوى القابل للتقديم فقط؛ يختفي في البث المباشر)
        seekCur = TextView(this).apply { text = "00:00"; setTextColor(Color.WHITE); textSize = 14f }
        seekTotal = TextView(this).apply { text = "00:00"; setTextColor(Color.WHITE); textSize = 14f }
        seekBar = SeekBar(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            max = 1000
            progressTintList = ColorStateList.valueOf(Color.parseColor("#FFC21A"))
            progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#66FFFFFF"))
            secondaryProgressTintList = ColorStateList.valueOf(Color.parseColor("#B3FFFFFF"))
            thumbTintList = ColorStateList.valueOf(Color.parseColor("#FFC21A"))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    val pl = player ?: return
                    val d = pl.duration
                    if (d <= 0) return
                    seekCur.text = fmtTime(d * progress / 1000)
                    if (!seekDragging) pl.seekTo(d * progress / 1000) // تحكم بالأسهم على الريموت
                }
                override fun onStartTrackingTouch(sb: SeekBar) {
                    seekDragging = true; main.removeCallbacks(hideControls)
                }
                override fun onStopTrackingTouch(sb: SeekBar) {
                    val pl = player
                    val d = pl?.duration ?: 0L
                    if (pl != null && d > 0) pl.seekTo(d * sb.progress / 1000)
                    seekDragging = false
                    showControls()
                }
            })
        }
        seekBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR // الشريط يمشي من اليسار لليمين، والوقت الحالي باليسار
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(seekCur, LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(seekTotal, LinearLayout.LayoutParams(WRAP, WRAP))
            })
            addView(seekBar, LinearLayout.LayoutParams(MATCH, dp(36)))
        }

        // الصف السفلي: يسار (السرعة) — وسط (تشغيل) — يمين (صوت/ترجمة/قفل)
        val leftBox = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            addView(speedBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
        }
        val centerBox = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(prevBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
            addView(back5, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginStart = dp(6) })
            addView(playPauseChip, LinearLayout.LayoutParams(dp(66), dp(66)).apply { marginStart = dp(14); marginEnd = dp(14) })
            addView(fwd5, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginEnd = dp(6) })
            addView(nextBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
        }
        val rightBox = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            addView(muteChip, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(8) })
            addView(ccBtn, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(8) })
            addView(lockBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
        }
        val bottomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(leftBox, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(centerBox, LinearLayout.LayoutParams(WRAP, WRAP))
            addView(rightBox, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        val bottomStack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), 0, dp(20), dp(10))
            addView(seekBlock, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(bottomRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        }
        // الأزرار التي تختفي عند قفل الشاشة (يبقى زر القفل فقط)
        lockables = listOf(topRow, qualityBar, leftBox, centerBox, muteChip, ccBtn)

        // ستارتان خفيفتان لتوضيح الأزرار فوق الصورة
        val scrim = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, Color.parseColor("#CC000000"))
            )
        }
        val scrimTop = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#99000000"), Color.TRANSPARENT)
            )
        }

        controlsLayer = FrameLayout(this).apply {
            addView(scrim, FrameLayout.LayoutParams(MATCH, dp(190), Gravity.BOTTOM))
            addView(scrimTop, FrameLayout.LayoutParams(MATCH, dp(90), Gravity.TOP))
            addView(qualityBar, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START)
                .apply { setMargins(dp(12), dp(12), 0, 0) })
            addView(topRow, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END)
                .apply { setMargins(0, dp(12), dp(16), 0) })
            addView(buffSpinner, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
            addView(bottomStack, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        }
        hudBrightness = hudView(R.drawable.hz_ic_sun)
        hudVolume = hudView(R.drawable.hz_ic_volume)
        controlsLocked = false
        // لمس ذكي: نقرة لإظهار الأدوات، نقرتان للتشغيل/الإيقاف، وسحب للتحكم.
        playerGestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                when {
                    panel.visibility == View.VISIBLE -> closePanel()
                    controlsLayer.visibility == View.VISIBLE -> {
                        main.removeCallbacks(hideControls); controlsLayer.visibility = View.GONE
                    }
                    else -> showControls()
                }
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (controlsLocked) return true
                togglePlayPause()
                return true
            }
        })
        playerView.setOnTouchListener { v, event ->
            playerGestures.onTouchEvent(event)
            if (controlsLocked) return@setOnTouchListener true
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    gestureDownX = event.x; gestureDownY = event.y; gestureMode = 0
                    gestureStartPosition = player?.currentPosition ?: 0L
                    val am = getSystemService(AUDIO_SERVICE) as AudioManager
                    gestureStartVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                    gestureMaxVolume = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    gestureStartBrightness = window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - gestureDownX
                    val dy = event.y - gestureDownY
                    if (gestureMode == 0 && (kotlin.math.abs(dx) > dp(18) || kotlin.math.abs(dy) > dp(18))) {
                        gestureMode = if (kotlin.math.abs(dx) > kotlin.math.abs(dy)) 1
                            else if (gestureDownX > v.width / 2f) 2 else 3
                        showControls()
                    }
                    when (gestureMode) {
                        1 -> {
                            val p = player
                            if (p != null && !p.isCurrentMediaItemLive && p.isCurrentMediaItemSeekable) {
                                val delta = (dx / v.width.coerceAtLeast(1) * 120_000L).toLong()
                                val target = (gestureStartPosition + delta).coerceIn(0L, p.duration.coerceAtLeast(0L))
                                p.seekTo(target)
                            }
                        }
                        2 -> {
                            val am = getSystemService(AUDIO_SERVICE) as AudioManager
                            val steps = (-dy / v.height.coerceAtLeast(1) * gestureMaxVolume).toInt()
                            val newVol = (gestureStartVolume + steps).coerceIn(0, gestureMaxVolume)
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0)
                            showHud(hudVolume, newVol * 100 / gestureMaxVolume)
                        }
                        3 -> {
                            val lp = window.attributes
                            lp.screenBrightness = (gestureStartBrightness - dy / v.height.coerceAtLeast(1)).coerceIn(0.05f, 1f)
                            window.attributes = lp
                            showHud(hudBrightness, (lp.screenBrightness * 100).toInt())
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (gestureMode != 0) {
                        val now = android.os.SystemClock.elapsedRealtime()
                        if (now - lastGestureToast > 700) {
                            val message = when (gestureMode) {
                                1 -> if (player?.isCurrentMediaItemLive == true) "البث مباشر — التقديم غير متاح" else "تم تغيير موضع التشغيل"
                                2 -> "مستوى صوت الجهاز"
                                else -> "سطوع الشاشة"
                            }
                            toast(message); lastGestureToast = now
                        }
                    }
                    gestureMode = 0
                    true
                }
                else -> true
            }
        }
        show(FrameLayout(this).apply {
            addView(playerView, MATCH, MATCH)
            addView(controlsLayer, MATCH, MATCH)
            addView(infoCard, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START)
                .apply { setMargins(dp(12), 0, 0, dp(170)) })
            addView(hudBrightness, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.CENTER_VERTICAL)
                .apply { setMargins(dp(48), 0, 0, dp(40)) })
            addView(hudVolume, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL)
                .apply { setMargins(0, 0, dp(48), dp(40)) })
            addView(panel, FrameLayout.LayoutParams(
                minOf(dp(340), (resources.displayMetrics.widthPixels * 0.84f).toInt()), MATCH, Gravity.END
            ))
        }, slide = false)
        bgView.visibility = View.GONE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setFullscreen(true)
    }

    // ================= أدوات واجهة المشغّل الجديدة =================

    /** زر أيقونة بخلفية شفافة (أو حلقة بيضاء للزر الدائري)، مع إبراز عند التركيز بالريموت. */
    private fun iconButton(res: Int, desc: String, iconDp: Int = 26, boxDp: Int = 46,
                           ring: Boolean = false, onClick: () -> Unit): ImageView = ImageView(this).apply {
        setImageResource(res)
        scaleType = ImageView.ScaleType.FIT_CENTER
        val pad = dp((boxDp - iconDp) / 2)
        setPadding(pad, pad, pad, pad)
        contentDescription = desc
        isFocusable = true
        isFocusableInTouchMode = false
        isClickable = true
        fun bg(focused: Boolean) = GradientDrawable().apply {
            if (ring) { shape = GradientDrawable.OVAL; setStroke(dp(2), Color.WHITE) }
            else cornerRadius = dp(boxDp / 2).toFloat()
            setColor(if (focused) Color.parseColor("#44FFFFFF") else Color.TRANSPARENT)
        }
        background = bg(false)
        setOnFocusChangeListener { _, f -> background = bg(f) }
        setOnClickListener { onClick() }
    }

    /** زر تقديم/رجوع مع الرقم 5 في وسطه. */
    private fun seekButton(res: Int, desc: String, onClick: () -> Unit): FrameLayout = FrameLayout(this).apply {
        addView(iconButton(res, desc, 40, 52, false, onClick), FrameLayout.LayoutParams(dp(52), dp(52)))
        addView(TextView(context).apply {
            text = "5"; setTextColor(Color.WHITE); textSize = 11f
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(dp(52), dp(52)))
    }

    private fun hudView(res: Int) = TextView(this).apply {
        setTextColor(Color.WHITE); textSize = 22f
        gravity = Gravity.CENTER_VERTICAL
        compoundDrawablePadding = dp(12)
        setCompoundDrawablesRelativeWithIntrinsicBounds(res, 0, 0, 0)
        setPadding(dp(14), dp(8), dp(16), dp(8))
        background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(Color.parseColor("#99000000")) }
        visibility = View.GONE
    }

    private val hideHud = Runnable {
        if (::hudBrightness.isInitialized) hudBrightness.visibility = View.GONE
        if (::hudVolume.isInitialized) hudVolume.visibility = View.GONE
    }

    private fun showHud(v: TextView, pct: Int) {
        v.text = "$pct%"
        v.visibility = View.VISIBLE
        main.removeCallbacks(hideHud)
        main.postDelayed(hideHud, 900)
    }

    private fun setPlayIcon(playing: Boolean) =
        playPauseChip.setImageResource(if (playing) R.drawable.hz_ic_pause else R.drawable.hz_ic_play)

    private fun setMuteIcon(muted: Boolean) =
        muteChip.setImageResource(if (muted) R.drawable.hz_ic_mute else R.drawable.hz_ic_volume)

    private fun fmtTime(ms: Long): String {
        val t = (ms / 1000).coerceAtLeast(0)
        val h = t / 3600; val m = (t % 3600) / 60; val sec = t % 60
        return if (h > 0) String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(java.util.Locale.US, "%02d:%02d", m, sec)
    }

    /** تحديث شريط التقدّم كل نصف ثانية؛ ظاهر دائماً (في البث المباشر بدون مدة يظهر خطاً كاملاً). */
    private val progressTick = object : Runnable {
        override fun run() {
            val p = player
            if (p != null && ::seekBlock.isInitialized) {
                val d = p.duration
                val hasWindow = d != C.TIME_UNSET && d > 0
                // الشريط ظاهر دائماً (بث، أفلام، مسلسلات) إلا عند قفل الأزرار
                seekBlock.visibility = if (controlsLocked) View.GONE else View.VISIBLE
                if (!seekDragging) {
                    if (hasWindow) {
                        seekBar.isEnabled = p.isCurrentMediaItemSeekable
                        seekBar.progress = (p.currentPosition * 1000 / d).toInt().coerceIn(0, 1000)
                        seekBar.secondaryProgress = (p.bufferedPosition * 1000 / d).toInt().coerceIn(0, 1000)
                        seekCur.text = fmtTime(p.currentPosition)
                        seekTotal.text = fmtTime(d)
                    } else if (p.playbackState == androidx.media3.common.Player.STATE_READY) {
                        // بث مباشر بدون مدة: خط كامل بدون تقديم
                        seekBar.isEnabled = false
                        seekBar.progress = 1000
                        seekBar.secondaryProgress = 1000
                        seekCur.text = "● مباشر"
                        seekTotal.text = "LIVE"
                    } else {
                        seekBar.isEnabled = false
                        seekBar.progress = 0
                        seekBar.secondaryProgress = 0
                        seekCur.text = "00:00"
                        seekTotal.text = "00:00"
                    }
                }
            }
            main.postDelayed(this, 500)
        }
    }

    private fun applyLock() {
        val vis = if (controlsLocked) View.GONE else View.VISIBLE
        lockables.forEach { it.visibility = vis }
        if (controlsLocked && panel.visibility == View.VISIBLE) closePanel()
        lockBtn.setImageResource(if (controlsLocked) R.drawable.hz_ic_lock else R.drawable.hz_ic_unlock)
        showControls()
    }

    private fun cycleSpeed() {
        val p = player ?: return
        if (p.isCurrentMediaItemLive) { toast("السرعة غير متاحة في البث المباشر"); return }
        speedIndex = (speedIndex + 1) % speedSteps.size
        val sp = speedSteps[speedIndex]
        p.setPlaybackSpeed(sp)
        toast("السرعة ${sp}x")
        showControls()
    }

    private fun rotateScreen() {
        val portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        showControls()
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
            } catch (_: Throwable) { toast("الصورة داخل صورة غير مدعومة") }
        } else toast("الصورة داخل صورة غير مدعومة")
    }

    /** لقطة شاشة من الفيديو وحفظها في معرض الصور (أندرويد 10 فأعلى). */
    private fun takeScreenshot() {
        val sv = playerView.videoSurfaceView as? android.view.SurfaceView
        if (sv == null || sv.width == 0 || sv.height == 0 || Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            toast("اللقطة غير مدعومة على هذا الجهاز"); return
        }
        try {
            val bmp = android.graphics.Bitmap.createBitmap(sv.width, sv.height, android.graphics.Bitmap.Config.ARGB_8888)
            android.view.PixelCopy.request(sv, bmp, { result ->
                if (result != android.view.PixelCopy.SUCCESS) { toast("تعذّر أخذ اللقطة"); return@request }
                try {
                    val cv = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "Horizon_${System.currentTimeMillis()}.jpg")
                        put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(android.provider.MediaStore.Images.Media.RELATIVE_PATH,
                            android.os.Environment.DIRECTORY_PICTURES + "/Horizon")
                    }
                    val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    if (uri == null) { toast("تعذّر حفظ اللقطة"); return@request }
                    contentResolver.openOutputStream(uri)?.use { out ->
                        bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, out)
                    }
                    toast("تم حفظ اللقطة في الصور")
                } catch (_: Throwable) { toast("تعذّر حفظ اللقطة") }
            }, main)
        } catch (_: Throwable) { toast("تعذّر أخذ اللقطة") }
        showControls()
    }

    /** زر دائري لأدوات المشغل (تشغيل/إيقاف/تالي/سابق/كتم). */
    private fun playerIconChip(symbol: String, onClick: () -> Unit) = TextView(this).apply {
        text = symbol
        textSize = 18f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        isFocusable = true; isFocusableInTouchMode = false
        contentDescription = when (symbol) {
            "▶", "⏸" -> "تشغيل أو إيقاف مؤقت"
            "🔊", "🔇" -> "كتم أو تشغيل الصوت"
            "⏮" -> "القناة السابقة"
            "⏭" -> "القناة التالية"
            "−10" -> "تأخير عشر ثوانٍ"
            "+10" -> "تقديم عشر ثوانٍ"
            else -> symbol
        }
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#26FFFFFF"))
            setStroke(dp(1), BORDER)
        }
        setOnFocusChangeListener { _, focused ->
            animate().scaleX(if (focused) 1.13f else 1f).scaleY(if (focused) 1.13f else 1f)
                .setDuration(140).start()
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (focused) Color.parseColor("#665B45D6") else Color.parseColor("#26FFFFFF"))
                setStroke(dp(if (focused) 2 else 1), if (focused) Color.WHITE else BORDER)
            }
        }
        setOnHoverListener { view, event ->
            if (event.action == MotionEvent.ACTION_HOVER_ENTER) view.requestFocus()
            false
        }
        setOnClickListener { throttle { onClick() } }
        pressFx(this)
    }

    private fun togglePlayPause() {
        val p = player ?: return
        p.playWhenReady = !p.playWhenReady
        setPlayIcon(p.playWhenReady)
        showControls()
    }

    /** عند وجود صوت خارجي: صوت الفيديو الأصلي صامت والصوت يخرج من القناة المختارة. */
    private fun applyVolumes() {
        val v = if (isMuted) 0f else 1f
        val e = extPlayer
        if (e != null) { e.volume = v; player?.volume = 0f } else player?.volume = v
    }

    private fun stopExtAudio() {
        extPlayer?.let { runCatching { it.release() } }
        extPlayer = null; extName = null; extDelayMs = 0L
        extChipView?.text = "صوت قناة أخرى"
        applyVolumes()
    }

    private fun startExtAudio(ch2: Channel, quiet: Boolean = false) {
        val key = listOf("SD", "HD", "Live", "VOD").firstOrNull { ch2.streams.containsKey(it) } ?: ch2.streams.keys.firstOrNull() ?: return
        val raw = ch2.streams[key] ?: return
        val dec = com.horizon.tv.utils.SecurityUtils.decrypt(raw)
        val url = if (dec.startsWith("http://") || dec.startsWith("https://")) dec else raw
        if (!url.startsWith("http")) { toast("تعذّر فتح صوت هذه القناة"); return }
        extPlayer?.let { runCatching { it.release() } }
        val e = buildExoPlayer()
        // لا ننازع المشغّل الرئيسي على Audio Focus، ونعطّل الفيديو لتوفير الأداء
        e.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), false)
        e.trackSelectionParameters = e.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build()
        e.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (extPlayer === e) { toast("تعذّر تشغيل صوت ${ch2.name}"); stopExtAudio() }
            }
        })
        extPlayer = e; extName = ch2.name; extDelayMs = 0L
        e.setMediaItem(mediaItemFor(url, false))
        e.prepare()
        e.playWhenReady = player?.playWhenReady ?: true
        extChipView?.text = "صوت: ${ch2.name}"
        applyVolumes()
        if (!quiet) toast("صوت ${ch2.name} فوق الفيديو")
    }

    /** يؤخّر الصوت الخارجي (موجب) أو يقدّمه (سالب) بالرجوع/التقدم داخل نافذة البث المباشر. */
    private fun adjustExtDelay(deltaMs: Long) {
        val e = extPlayer ?: return
        if (!e.isCurrentMediaItemSeekable) { toast("هذا البث لا يدعم ضبط التزامن"); return }
        e.seekTo((e.currentPosition - deltaMs).coerceAtLeast(0L))
        extDelayMs += deltaMs
        toast("تأخير الصوت: ${"%.1f".format(extDelayMs / 1000.0)} ث")
    }

    private fun showExtAudioPicker() {
        val c = content ?: return
        val groups = c.channels.filter { it.channels.isNotEmpty() }
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        if (extPlayer != null) {
            labels += "إيقاف صوت ${extName}"; actions += { stopExtAudio() }
            labels += "تأخير الصوت 1 ثانية"; actions += { adjustExtDelay(1000) }
            labels += "تقديم الصوت 1 ثانية"; actions += { adjustExtDelay(-1000) }
        }
        groups.forEach { g ->
            labels += g.name
            actions += {
                AlertDialog.Builder(this)
                    .setTitle(g.name)
                    .setItems(g.channels.map { it.name }.toTypedArray()) { _, i -> startExtAudio(g.channels[i]) }
                    .setNegativeButton("رجوع", null)
                    .show()
            }
        }
        AlertDialog.Builder(this)
            .setTitle("استخدام صوت من قناة أخرى")
            .setItems(labels.toTypedArray()) { _, i -> actions[i]() }
            .setNegativeButton("إغلاق", null)
            .show()
            .window?.let { w ->
                w.decorView.isFocusableInTouchMode = true
                w.decorView.requestFocus()
            }
        showControls()
    }

    private fun toggleMute() {
        isMuted = !isMuted
        applyVolumes()
        setMuteIcon(isMuted)
        showControls()
    }

    /** ينتقل للقناة التالية/السابقة داخل نفس القائمة المفتوحة حالياً. */
    private fun stepChannel(dir: Int) {
        val ch = curCh ?: return
        if (playlist.isEmpty()) return
        val i = playlist.indexOfFirst { it.name == ch.name }
        if (i < 0) return
        val next = playlist[(i + dir + playlist.size) % playlist.size]
        play(next, curSub)
    }

    /** تأخير تلقائي حسب الشبكة: قوية 5–10 ثوانٍ، ضعيفة 10–20 ثانية، ويزيد تلقائياً إذا تكرر التقطيع ثم ينزل عند الهدوء. */
    private fun autoDelaySec(): Int {
        val mbps = androidx.media3.exoplayer.upstream.DefaultBandwidthMeter.getSingletonInstance(this).bitrateEstimate / 1_000_000.0
        val base = when {
            mbps >= 25 -> 5
            mbps >= 10 -> 7
            mbps >= 5 -> 10
            mbps >= 2.5 -> 14
            else -> 18
        }
        return (base + prefs().getInt("auto_penalty_sec", 0)).coerceIn(5, 20)
    }

    private fun registerStall() {
        val pen = prefs().getInt("auto_penalty_sec", 0)
        prefs().edit().putInt("auto_penalty_sec", (pen + 2).coerceAtMost(10)).apply()
        lastStallAt = System.currentTimeMillis()
    }

    /** يعرض/يخفي لوحة إحصائيات: الدقة، الإطارات الساقطة، المخزن، المفكّك، وموديل الجهاز. */
    private fun toggleStats() {
        val frame = playerView.overlayFrameLayout ?: return
        statsOn = !statsOn
        if (!statsOn) {
            statsView?.let { frame.removeView(it) }
            statsView = null
            return
        }
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 11f
            typeface = android.graphics.Typeface.MONOSPACE
            setBackgroundColor(Color.parseColor("#B0000000"))
            setPadding(dp(8), dp(6), dp(8), dp(6))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        statsView = tv
        frame.addView(tv, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.LEFT).apply { topMargin = dp(70); leftMargin = dp(8) })
        lateinit var tick: Runnable
        tick = Runnable {
            if (!statsOn || statsView !== tv) return@Runnable
            val p = player
            if (p != null) {
                val vf = p.videoFormat
                val state = when (p.playbackState) {
                    Player.STATE_BUFFERING -> "BUFFERING"; Player.STATE_READY -> "READY"
                    Player.STATE_ENDED -> "ENDED"; else -> "IDLE"
                }
                val live = if (p.currentLiveOffset != C.TIME_UNSET) "%.1fs".format(p.currentLiveOffset / 1000.0) else "-"
                tv.text = buildString {
                    append("${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})\n")
                    append("video: ${vf?.width}x${vf?.height} @${vf?.frameRate} fps  ${(vf?.bitrate ?: 0) / 1000} kbps\n")
                    append("codec: ${vf?.sampleMimeType}  decoder: $videoDecoder\n")
                    append("buffer: %.1fs  live offset: %s  speed: %.2f\n".format(p.totalBufferedDuration / 1000.0, live, p.playbackParameters.speed))
                    append("auto delay: ${autoDelaySec()}s (penalty ${prefs().getInt("auto_penalty_sec", 0)}s)\n")
                    append("dropped frames: $droppedFrames  state: $state")
                }
            }
            main.postDelayed(tick, 1000)
        }
        main.post(tick)
    }

    // حماية: إغلاق التطبيق إذا اشتغل VPN أو بروكسي أو أداة مراقبة (يفحص كل 3 ثوانٍ وقبل كل تشغيل)
    private var guardOn = true
    private var guardStarted = false
    private val guardHandler = Handler(Looper.getMainLooper())

    private fun applySecurity(c: Content?) {
        if (c == null) return
        guardOn = c.blockVpn
        if (guardStarted) return
        guardStarted = true
        guardHandler.post(object : Runnable {
            override fun run() { guardCheck(); guardHandler.postDelayed(this, 3000) }
        })
    }

    private fun guardCheck() {
        if (!guardOn) return
        val why = Guard.reason(this) ?: return
        toast("تم إغلاق التطبيق: أوقف $why ثم افتحه من جديد")
        guardHandler.removeCallbacksAndMessages(null)
        runCatching { stopPlayer() }
        finishAffinity()
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    private fun prefetchOverlays(c: Content?) {
        if (c == null) return
        (c.channels.flatMap { it.channels } + c.movies.flatMap { it.channels })
            .mapNotNull { it.overlay?.url }.distinct().forEach { ImageLoader.prefetch(it) }
    }

    /** صوت تلقائي من قناة أخرى (حقل audioFrom): الصورة من هذه القناة والصوت من المصدر المحدد. */
    private fun applyAudioFrom(ch: Channel) {
        val target = ch.audioFrom.trim()
        if (target.isEmpty() || extPlayer != null) return
        val byName = content?.channels?.flatMap { it.channels }?.firstOrNull { it.name.equals(target, true) }
        val src = byName ?: Channel("مخصص", mapOf("Live" to target))
        startExtAudio(src, quiet = true)
    }

    /** يضع الشعار الخاص داخل مساحة الفيديو نفسها (لا زاوية الشاشة) ليغطي شعار القناة الأصلي. */
    private fun applyOverlay(ch: Channel) {
        val frame = playerView.overlayFrameLayout ?: return
        overlayImg?.let { frame.removeView(it) }
        overlayImg = null
        val o = ch.overlay ?: return
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = o.heightPct <= 0f
            o.bg?.let { setBackgroundColor(it); setPadding(dp(4), dp(3), dp(4), dp(3)) }
        }
        val gravity = when (o.pos) {
            "tl" -> Gravity.TOP or Gravity.LEFT
            "bl" -> Gravity.BOTTOM or Gravity.LEFT
            "br" -> Gravity.BOTTOM or Gravity.RIGHT
            else -> Gravity.TOP or Gravity.RIGHT
        }
        val lp = FrameLayout.LayoutParams(WRAP, WRAP, gravity).apply { setMargins(dp(o.mx), dp(o.my), dp(o.mx), dp(o.my)) }
        overlayImg = img
        frame.addView(img, lp)
        fun fit() {
            val w = (frame.width * o.widthPct / 100f).toInt()
            val h = if (o.heightPct > 0f) (frame.height * o.heightPct / 100f).toInt() else WRAP
            if (w > 0 && (lp.width != w || lp.height != h)) { lp.width = w; lp.height = h; img.layoutParams = lp }
        }
        frame.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fit() }
        frame.post { fit() }
        ImageLoader.load(o.url, img)
    }

    private fun startStream(ch: Channel, sub: String, quality: String) {
        val url = ch.streams[quality] ?: return
        val qualities = ch.streams.keys.toList()
        retries = 0
        guardCheck()
        if (curCh?.name != ch.name) stopExtAudio()
        curCh = ch
        curQuality = quality
        applyOverlay(ch)
        applyAudioFrom(ch)
        retryRunnable?.let { main.removeCallbacks(it) }
        retryRunnable = null
        infoFade?.let { main.removeCallbacks(it) }

        qualityBar.removeAllViews()
        if (qualities.size > 1) qualities.forEach { q ->
            qualityBar.addView(chip(q, q == quality) { startStream(ch, sub, q) },
                LinearLayout.LayoutParams(WRAP, dp(38)).apply { marginEnd = dp(6) })
        }

        infoName.text = ch.name
        infoCat.text = sub
        infoCard.animate().cancel()
        infoCard.alpha = 1f
        infoFade = Runnable { infoCard.animate().alpha(0f).setDuration(700).start() }
            .also { main.postDelayed(it, 3500) }

        setPlayIcon(true)
        setMuteIcon(isMuted)
        speedIndex = 0
        main.removeCallbacks(progressTick); main.post(progressTick)
        buffSpinner.visibility = View.VISIBLE

        playerView.player = null
        player?.release()

        // فك تشفير الرابط قبل تمريره للمشغل، مع دعم الروابط غير المشفّرة
        val decryptedUrl = com.horizon.tv.utils.SecurityUtils.decrypt(url)
        val playbackUrl = if (decryptedUrl.isNotBlank() &&
            (decryptedUrl.startsWith("http://") || decryptedUrl.startsWith("https://"))) {
            decryptedUrl
        } else {
            url
        }
        // روابط السيرفرات البديلة لنفس الجودة. تبقى الروابط القديمة (String) كما هي.
        fun resolveStream(candidate: String): String {
            val decoded = com.horizon.tv.utils.SecurityUtils.decrypt(candidate)
            return if (decoded.isNotBlank() &&
                (decoded.startsWith("http://") || decoded.startsWith("https://"))) decoded
            else candidate
        }
        val serverCandidates = (listOf(url) + ch.backupStreams[quality].orEmpty())
            .map(::resolveStream).filter { it.startsWith("http://") || it.startsWith("https://") }
            .distinct()
        var activeServerIndex = 0
        var triedHls = false
        fun switchToNextServer(p: ExoPlayer): Boolean {
            if (activeServerIndex + 1 >= serverCandidates.size) return false
            activeServerIndex++
            triedHls = false
            retries = 0
            Log.w("HorizonFailover", "Switching to backup ${activeServerIndex + 1}/${serverCandidates.size} for ${ch.name} [$quality]")
            p.setMediaItem(mediaItemFor(serverCandidates[activeServerIndex], false))
            p.prepare()
            p.playWhenReady = true
            return true
        }
        var endedBursts = 0
        var lastEndedAt = 0L
        var audioFallbackTried = false
        var wasReady = false
        val p = buildExoPlayer()
        p.volume = if (isMuted || extPlayer != null) 0f else 1f
        droppedFrames = 0L
        // حارس تجمّد الصورة: يكشف توقف عرض الإطارات حتى لو لم يظهر "تحميل" (الحالة التي رأيناها بالفيديو)
        lastFrameAt = System.currentTimeMillis()
        lastStallAt = System.currentTimeMillis()
        p.setVideoFrameMetadataListener(androidx.media3.exoplayer.video.VideoFrameMetadataListener { _, _, _, _ ->
            lastFrameAt = System.currentTimeMillis()
        })
        val freezeWatch = object : Runnable {
            override fun run() {
                if (player !== p) return
                val nowD = System.currentTimeMillis()
                val pen = prefs().getInt("auto_penalty_sec", 0)
                if (pen > 0 && p.playbackState == Player.STATE_READY && nowD - lastStallAt > 180_000) {
                    prefs().edit().putInt("auto_penalty_sec", pen - 1).apply()
                    lastStallAt = nowD
                }
                val live = p.isCurrentMediaItemLive || p.duration == C.TIME_UNSET || !p.isCurrentMediaItemSeekable
                val now = System.currentTimeMillis()
                if (p.playWhenReady && p.playbackState == Player.STATE_READY && p.videoFormat != null &&
                    live && now - lastFrameAt > 3500) {
                    freezeHits.removeAll { now - it > 30_000 }
                    freezeHits.add(now)
                    registerStall()
                    lastFrameAt = now
                    if (freezeHits.size >= 3 && switchToNextServer(p)) freezeHits.clear()
                    else { if (!p.isCurrentMediaItemSeekable) p.seekToDefaultPosition(); p.prepare() }
                }
                main.postDelayed(this, 1500)
            }
        }
        main.postDelayed(freezeWatch, 4000)
        p.addAnalyticsListener(object : androidx.media3.exoplayer.analytics.AnalyticsListener {
            override fun onDroppedVideoFrames(eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime, droppedFrames: Int, elapsedMs: Long) {
                this@MainActivity.droppedFrames += droppedFrames
            }
            override fun onVideoDecoderInitialized(eventTime: androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime, decoderName: String, initializedTimestampMs: Long, initializationDurationMs: Long) {
                videoDecoder = decoderName
            }
        })
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                buffSpinner.visibility = View.GONE
                // البث المباشر تأخر عن النافذة: نقفز لأحدث نقطة بدل احتسابها خطأ
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    if (!p.isCurrentMediaItemSeekable) p.seekToDefaultPosition(); p.prepare(); return
                }
                // رابط بلا امتداد واضح وصيغته لم تُتعرَّف: نجرّبه كـ HLS مرة واحدة
                if (!triedHls && (error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                            error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED)) {
                    triedHls = true
                    p.setMediaItem(mediaItemFor(serverCandidates.getOrNull(activeServerIndex) ?: playbackUrl, true))
                    p.prepare(); p.playWhenReady = true
                    return
                }
                // عند فشل السيرفر الحالي ننتقل فوراً إلى السيرفر الاحتياطي لنفس الجودة، بلا انتظار retries.
                if (switchToNextServer(p)) return
                val delay = (1000L * (retries + 1)).coerceAtMost(4000)
                if (retries++ < 3) {
                    toast("إعادة الاتصال خلال ${delay / 1000}ث...")
                    retryRunnable = Runnable { p.prepare() }.also { main.postDelayed(it, delay) }
                } else {
                    val next = qualities.getOrNull(qualities.indexOf(quality) + 1)
                    if (next != null) {
                        toast("تحويل تلقائي إلى $next")
                        main.post { startStream(ch, sub, next) }
                    } else {
                        toast("تعذّر تشغيل القناة")
                        main.post { leavePlayer() }
                    }
                }
            }
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                // تشخيص مسارات الصوت: يوضح هل البث يحتوي صوتاً أصلاً وهل يستطيع الجهاز فك ترميزه.
                val audioGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
                if (audioGroups.isEmpty()) {
                    Log.w("HorizonAudio", "No audio track exposed by stream: $playbackUrl")
                } else {
                    audioGroups.forEachIndexed { index, group ->
                        val formats = (0 until group.length).map { group.getTrackFormat(it) }
                        formats.forEach { format ->
                            Log.i("HorizonAudio", "track=$index supported=${group.isSupported} selected=${group.isSelected} mime=${format.sampleMimeType} codecs=${format.codecs} channels=${format.channelCount} sampleRate=${format.sampleRate} language=${format.language}")
                        }
                    }
                    if (audioGroups.none { it.isSupported }) {
                        Log.e("HorizonAudio", "Audio tracks exist but none are supported by this device/player")
                        // إصلاح "ماكو صوت": الجهاز لا يفك ترميز صوت هذا البث (مثل AC3 في بث 4K).
                        // نعرض نوع الصوت، ونحوّل تلقائياً لجودة ثانية من نفس القناة إن وُجدت.
                        val codec = audioGroups.firstNotNullOfOrNull { g ->
                            (0 until g.length).map { g.getTrackFormat(it).sampleMimeType }.firstOrNull()
                        }.orEmpty().substringAfter('/')
                        val other = qualities.firstOrNull { it != quality }
                        if (!audioFallbackTried && other != null) {
                            audioFallbackTried = true
                            toast("صوت هذه الجودة ($codec) غير مدعوم، تحويل إلى $other")
                            main.post { if (player === p) startStream(ch, sub, other) }
                        } else {
                            toast("صوت هذا البث غير مدعوم على جهازك ($codec)")
                        }
                    }
                }
            }
            // إصلاح التوقف: عند فقدان Audio Focus (إشعار/تطبيق آخر) يتوقف المشغّل ولا يكمل وحده، فنعيد التشغيل.
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (player === p) extPlayer?.playWhenReady = playWhenReady
                if (!playWhenReady && reason == Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_FOCUS_LOSS &&
                    screen == Screen.PLAYER && player === p) {
                    main.post { if (player === p) p.playWhenReady = true }
                }
            }
            override fun onPlaybackStateChanged(state: Int) {
                buffSpinner.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
                // تعلّم تلقائي: كل تقطيع (تحميل بعد تشغيل) يرفع التأخير المقترح قليلاً
                if (state == Player.STATE_READY) wasReady = true
                else if (state == Player.STATE_BUFFERING && wasReady && player === p) { wasReady = false; registerStall() }
                // إصلاح التوقف: السيرفر يقفل اتصال البث الحي فيعتبره المشغّل "انتهى" فيجمد على آخر صورة بلا خطأ.
                // نعيد الاتصال تلقائياً، وإذا تكرر خلال ثوانٍ ننتقل للسيرفر الاحتياطي.
                if (state == Player.STATE_ENDED && player === p && p.playWhenReady &&
                    (p.duration == C.TIME_UNSET || !p.isCurrentMediaItemSeekable || p.isCurrentMediaItemLive)) {
                    val now = System.currentTimeMillis()
                    endedBursts = if (now - lastEndedAt < 10_000) endedBursts + 1 else 1
                    lastEndedAt = now
                    main.postDelayed({
                        if (player === p && p.playbackState == Player.STATE_ENDED) {
                            if (endedBursts >= 3 && switchToNextServer(p)) {
                                endedBursts = 0
                            } else {
                                p.seekToDefaultPosition(); p.prepare(); p.playWhenReady = true
                            }
                        }
                    }, 300)
                }
                if (state == Player.STATE_READY) retries = 0
                // حارس التوقف: إذا علق البث بالتحميل أكثر من 15 ثانية نعيد الاتصال تلقائياً
                stallRunnable?.let { main.removeCallbacks(it) }
                stallRunnable = null
                if (state == Player.STATE_BUFFERING) {
                    stallRunnable = Runnable {
                        if (player === p && p.playWhenReady && p.playbackState == Player.STATE_BUFFERING) {
                            toast("البث متوقف، جاري إعادة الاتصال...")
                            if (!switchToNextServer(p)) {
                                if (p.isCurrentMediaItemLive) p.seekToDefaultPosition()
                                p.prepare()
                            }
                        }
                    }.also { main.postDelayed(it, 6_000) }
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                setPlayIcon(isPlaying)
            }
        })
        playerView.player = p
        registerNetworkWatch()
        p.setMediaItem(mediaItemFor(serverCandidates.firstOrNull() ?: playbackUrl, false))
        // البث الحي يتبع أحدث نقطة مع هامش قصير لتقليل التأخير والتقطيع.
        p.setSeekParameters(androidx.media3.exoplayer.SeekParameters.CLOSEST_SYNC)
        p.prepare()
        p.playWhenReady = true
        player = p
        showControls()
        updatePipParams()
    }

    // ---- الأزرار التي تختفي تلقائياً ----

    // إعدادات مسارات الفيديو والصوت والترجمة باستخدام Media3.
    // تظهر الخيارات المتاحة فعلياً في البث الحالي فقط.
    private fun showPlayerSettings() {
        val p = player ?: return
        val options = arrayOf("جودة الفيديو", "مسار الصوت", "الترجمة")
        AlertDialog.Builder(this)
            .setTitle("إعدادات المشغّل")
            .setItems(options) { dialog, which ->
                val trackType = when (which) {
                    0 -> C.TRACK_TYPE_VIDEO
                    1 -> C.TRACK_TYPE_AUDIO
                    else -> C.TRACK_TYPE_TEXT
                }
                val title = options[which]
                try {
                    TrackSelectionDialogBuilder(this, title, p, trackType)
                        .setShowDisableOption(which == 2)
                        .build()
                        .show()
                } catch (e: Exception) {
                    toast("لا توجد خيارات متاحة لهذا المسار")
                }
                showControls()
            }
            .setNegativeButton("إغلاق", null)
            .show()
            .window?.let { w ->
                w.decorView.isFocusableInTouchMode = true
                w.decorView.requestFocus()
            }
        showControls()
    }

    private fun showControls() {
        controlsLayer.visibility = View.VISIBLE
        // على Android TV يبدأ التركيز من زر التشغيل؛ الماوس واللمس يبقيان طبيعيين.
        val focused = currentFocus
        if (focused == null || !isDescendantOf(focused, controlsLayer)) {
            playPauseChip.post { if (controlsLayer.visibility == View.VISIBLE) playPauseChip.requestFocus() }
        }
        main.removeCallbacks(hideControls)
        main.postDelayed(hideControls, 6500)
    }

    private fun isDescendantOf(view: View, parent: ViewGroup): Boolean {
        var current: View? = view
        while (current != null) {
            if (current === parent) return true
            current = current.parent as? View
        }
        return false
    }

    // ---- قائمة التنقل داخل المشغّل ----

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) { closePanel(); return }
        panelShowGroups = false
        refreshPanel()
        panel.visibility = View.VISIBLE
        panel.translationX = dp(40).toFloat()
        panel.alpha = 0f
        panel.animate().translationX(0f).alpha(1f).setDuration(240)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closePanel() {
        panel.visibility = View.GONE
        showControls()
    }

    private fun refreshPanel() {
        panel.removeAllViews()
        val groups = panelGroups

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        if (groups != null && !panelShowGroups) header.addView(chip("‹", false) { panelShowGroups = true; refreshPanel() },
            LinearLayout.LayoutParams(WRAP, dp(38)).apply { marginEnd = dp(8) })
        header.addView(gradientText(if (panelShowGroups) "الأقسام" else playlistTitle, 17f),
            LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(chip("✕", false) { closePanel() }, LinearLayout.LayoutParams(WRAP, dp(38)))
        panel.addView(header, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })

        val rows: List<Row>
        val onRowClick: (Row) -> Unit
        if (panelShowGroups && groups != null) {
            rows = groups.mapIndexed { i, g -> Row("g:$i", g.name, listOf("${g.channels.size}")) }
            onRowClick = { row ->
                val g = groups.getOrNull(row.key.removePrefix("g:").toIntOrNull() ?: -1)
                if (g != null) {
                    playlist = g.channels
                    playlistTitle = g.name
                    curSub = g.name
                    panelShowGroups = false
                    refreshPanel()
                }
            }
        } else {
            rows = playlist.mapIndexed { i, ch -> Row("i:$i", ch.name) }
            onRowClick = { row ->
                val ch = playlist.getOrNull(row.key.removePrefix("i:").toIntOrNull() ?: -1)
                if (ch != null) { closePanel(); play(ch, curSub) }
            }
        }
        val lv = ListView(this).apply {
            adapter = object : BaseAdapter() {
                override fun getCount() = rows.size
                override fun getItem(p: Int) = rows[p]
                override fun getItemId(p: Int) = p.toLong()
                override fun getView(p: Int, v: View?, g: ViewGroup): View = rowView(rows[p], onRowClick, null)
            }
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(8)
            selector = ColorDrawable(Color.TRANSPARENT)
            isFocusable = true
            isFocusableInTouchMode = false
        }
        lv.post { if (lv.count > 0) { lv.setSelection(0); lv.requestFocus() } }
        panel.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    /** الخروج من المشغّل إلى القائمة التي فُتحت منها القناة. */
    private fun leavePlayer() {
        val b = playerBack
        showInterstitialThen {
            if (b != null) b() else showHome()
        }
    }

    /** عند فتح القناة: عرض أفقي وإخفاء أشرطة النظام. وعند الرجوع: يعود كما كان. */
    private fun setFullscreen(on: Boolean) {
        requestedOrientation = if (on) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else if (isTvMode()) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else c.show(WindowInsetsCompat.Type.systemBars())
    }

    // ================= Player engine =================

    /** مشغّل مضبوط للبث المباشر: مهلات أطول، تحويل http→https، بافر أكبر، ودعم TS/HLS الأضعف. */
    private fun buildExoPlayer(): ExoPlayer {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 11) HorizonTV/3.0")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(20000)
            .setReadTimeoutMs(30000)
        val extractors = DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)
            .setTsExtractorFlags(
                DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                    DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
            )
        val mediaSources = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http), extractors)
            // تحمّل أخطاء الشبكة العابرة (8 محاولات) بدل ما تظهر كتقطيع أو خطأ
            .setLoadErrorHandlingPolicy(androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy(8))
        // تأخير البث (ثوانٍ): المشاهد يبقى خلف المباشر بهذا المقدار، فالمخزن يغطي أي انقطاع أو بطء أقصر منه
        val delayMs = autoDelaySec() * 1000
        val loadControl = DefaultLoadControl.Builder()
            // وسادة ضد تذبذب الشبكة: لا يبدأ العرض إلا بعد تجميع 5 ثوانٍ، وبعد أي تقطيع ينتظر 10 ثوانٍ
            // فيتحول عدة تقطيعات صغيرة متتالية إلى توقف واحد أقل
            .setBufferDurationsMs(maxOf(20_000, delayMs + 10_000), maxOf(45_000, delayMs + 30_000), delayMs, delayMs)
            // سقف للذاكرة (80MB) + الاحتفاظ بـ45 ثانية خلفية ليقدر المشاهد يرجع للخلف في البث الذي يدعم ذلك
            .setTargetBufferBytes(80 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(false)
            .setBackBuffer(45_000, true)
            .build()
        // يفعّل الرجوع إلى مفككات النظام البديلة عند فشل المفكك الأول.
        // وضع EXTENSION_RENDERER_MODE_PREFER يبقى مفيداً إذا أضيفت امتدادات Media3 الصوتية لاحقاً.
        val renderers = DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        val selector = DefaultTrackSelector(this).apply {
            // لا نفك جودة أعلى من شاشة الجهاز: يخفف التقطيع على الأجهزة الضعيفة
            setParameters(buildUponParameters()
                .setViewportSizeToPhysicalDisplaySize(this@MainActivity, true)
                .setConstrainAudioChannelCountToDeviceCapabilities(false))
        }
        // تهيئة الصوت صراحةً كصوت وسائط مع إدارة Audio Focus في أندرويد.
        // هذا يساعد على إخراج الصوت بشكل صحيح عند الانتقال بين التطبيقات/الأجهزة.
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        return ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(mediaSources)
            .setLoadControl(loadControl)
            .setTrackSelector(selector)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
    }

    /** عند رجوع الإنترنت بعد انقطاع: نعيد تشغيل البث تلقائياً بدل ما يبقى واقف. */
    private fun registerNetworkWatch() {
        if (netCallback != null) return
        try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    main.post {
                        val p = player ?: return@post
                        if (screen == Screen.PLAYER && p.playWhenReady &&
                            (p.playerError != null || p.playbackState == Player.STATE_BUFFERING)) {
                            if (p.isCurrentMediaItemLive) p.seekToDefaultPosition()
                            p.prepare()
                        }
                    }
                }
            }
            cm.registerNetworkCallback(
                NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), cb)
            netCallback = cb
        } catch (_: Throwable) {}
    }

    private fun unregisterNetworkWatch() {
        val cb = netCallback ?: return
        netCallback = null
        try {
            (getSystemService(CONNECTIVITY_SERVICE) as? ConnectivityManager)?.unregisterNetworkCallback(cb)
        } catch (_: Throwable) {}
    }

    private fun mediaItemFor(u: String, forceHls: Boolean): MediaItem {
        val low = u.lowercase()
        val d = (autoDelaySec() * 1000).coerceAtLeast(3000)
        val b = MediaItem.Builder().setUri(u)
            // بث HLS المباشر: نبقى خلف الحافة الحية بـ15 ثانية كوسادة، وسرعة التشغيل ثابتة 1.0
            // (بدون تسريع/إبطاء تلقائي للّحاق بالبث لأنه يسبب رجفة بالصورة والصوت)
            .setLiveConfiguration(
                MediaItem.LiveConfiguration.Builder()
                    .setTargetOffsetMs(d.toLong()).setMinOffsetMs((d / 2).toLong()).setMaxOffsetMs((d * 3 + 10_000).toLong())
                    .setMinPlaybackSpeed(1f).setMaxPlaybackSpeed(1f).build()
            )
        when {
            forceHls || low.contains("m3u8") -> b.setMimeType(MimeTypes.APPLICATION_M3U8)
            low.substringBefore('?').endsWith(".mpd") -> b.setMimeType(MimeTypes.APPLICATION_MPD)
        }
        return b.build()
    }

    // ================= Remote control (Android TV) =================

    /** ريموت التلفاز: الأزرار تختفي بعد 4 ثوانٍ، فأي ضغطة تُظهرها بدل أن تضيع بين عناصر مخفية. */
    private fun adjustDeviceVolume(direction: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
            if (direction > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        if (p.isCurrentMediaItemLive || !p.isCurrentMediaItemSeekable) {
            toast("هذا البث مباشر ولا يدعم التقديم")
            return
        }
        val duration = p.duration.coerceAtLeast(0L)
        p.seekTo((p.currentPosition + deltaMs).coerceIn(0L, duration))
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (isTvMode() && screen == Screen.LIST && customView == null && webView != null && tvCursor != null) {
            if (handleBrowserKey(event)) return true
        }
        // بعض أجهزة Android TV ترسل OK كـ ENTER أو NUMPAD_ENTER؛ نفّذ العنصر المركّز مباشرةً.
        if (screen == Screen.LIST && event.action == KeyEvent.ACTION_DOWN &&
            (event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || event.keyCode == KeyEvent.KEYCODE_ENTER ||
                event.keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER)) {
            val adapterView = activeAdapterView
            if (adapterView != null && adapterView.isShown && adapterView.count > 0) {
                val focusedNow = currentFocus
                var position = if (focusedNow != null && isDescendantOf(focusedNow, adapterView))
                    adapterView.getPositionForView(focusedNow) else adapterView.selectedItemPosition
                if (position < 0) position = 0
                if (position in 0 until adapterView.count) {
                    adapterView.setSelection(position)
                    val child = adapterView.getChildAt(position - adapterView.firstVisiblePosition)
                    if (child != null && child.isEnabled) child.performClick()
                    else adapterView.performItemClick(adapterView.getChildAt(position - adapterView.firstVisiblePosition), position, adapterView.adapter.getItemId(position))
                    return true
                }
            }
            val focused = currentFocus
            if (focused != null && focused.isShown && focused.isEnabled && focused.isClickable) {
                focused.performClick()
                return true
            }
        }
        if (screen != Screen.PLAYER && screen != Screen.LIST && event.action == KeyEvent.ACTION_DOWN &&
            (event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || event.keyCode == KeyEvent.KEYCODE_ENTER ||
                event.keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER)) {
            val focused = currentFocus
            if (focused != null && focused.isShown && focused.isEnabled && focused.isClickable) {
                focused.performClick()
                return true
            }
        }
        if (screen == Screen.PLAYER && event.action == KeyEvent.ACTION_DOWN) {
            val k = event.keyCode
            val panelOpen = panel.visibility == View.VISIBLE
            val controlsHidden = controlsLayer.visibility != View.VISIBLE
            if (!panelOpen) {
                when (k) {
                    KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY,
                    KeyEvent.KEYCODE_MEDIA_PAUSE -> { togglePlayPause(); showControls(); return true }
                    KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> { stepChannel(1); showControls(); return true }
                    KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { stepChannel(-1); showControls(); return true }
                    KeyEvent.KEYCODE_VOLUME_UP -> { adjustDeviceVolume(1); showControls(); return true }
                    KeyEvent.KEYCODE_VOLUME_DOWN -> { adjustDeviceVolume(-1); showControls(); return true }
                    KeyEvent.KEYCODE_VOLUME_MUTE -> { toggleMute(); showControls(); return true }
                    KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_INFO -> { togglePanel(); return true }
                    KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-10_000L); showControls(); return true }
                    KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(10_000L); showControls(); return true }
                }
                if (controlsHidden && k != KeyEvent.KEYCODE_BACK) {
                    showControls()
                    if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER ||
                        k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN ||
                        k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT) {
                        playPauseChip.requestFocus()
                    }
                    return true
                }
                if (!controlsHidden) {
                    showControls() // تمديد مهلة الإخفاء أثناء التنقل بالريموت
                    // لا نبتلع الأسهم وOK: Android ينقل التركيز وينفذ الزر المحدد تلقائياً.
                    if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER ||
                        k == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                        val focused = currentFocus
                        if (focused != null && isDescendantOf(focused, controlsLayer)) {
                            focused.performClick()
                            return true
                        }
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // ================= Navigation =================

    private fun goBack() {
        if (customView != null) { hideCustomView(); return }
        val wv = webView
        if (screen == Screen.LIST && wv != null && wv.canGoBack()) { wv.goBack(); return }
        if (screen == Screen.PLAYER) {
            if (panel.visibility == View.VISIBLE) closePanel() else leavePlayer()
            return
        }
        val b = navBack
        if (b != null) b() else finish()
    }

    private fun stopPlayer() {
        main.removeCallbacksAndMessages(null)
        statsOn = false; statsView = null; overlayImg = null
        stopExtAudio()
        playerView.player = null
        player?.release()
        player = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onStart() { super.onStart(); player?.play(); webView?.onResume(); bgAnimator?.resume(); Stats.start(this, if (isTvMode()) "tv" else "phone", "4.9") }
    override fun onStop() {
        val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode
        if (!inPip) { player?.pause(); webView?.onPause(); bgAnimator?.pause() }
        Stats.stop()
        super.onStop()
    }
    override fun onDestroy() { bgAnimator?.cancel(); unregisterNetworkWatch(); destroyWebView(); stopPlayer(); super.onDestroy() }

    private fun updatePipParams() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                setPictureInPictureParams(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                )
            } catch (_: Throwable) {}
        }
    }

    override fun onUserLeaveHint() {
        if (screen == Screen.PLAYER && player?.isPlaying == true
            && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                )
            } catch (_: Throwable) {}
        }
        super.onUserLeaveHint()
    }

    // ================= واجهة التلفزيون: القنوات بالباقات + مؤشر الريموت =================

    private var tvCursor: ImageView? = null
    private var browserTopBar: View? = null
    private var cursorX = 0f
    private var cursorY = 0f
    private var cursorMode = true

    // ---- القنوات المباشرة للتلفزيون: الباقات يميناً، وقنوات الباقة مرقّمة يساراً ----

    private fun showTvLive(startIndex: Int = 0) {
        screen = Screen.LIST
        activeAdapterView = null
        navBack = { showHome() }
        setFullscreen(false)
        val groups = content?.channels.orEmpty()
            .filter { !isMovieSeriesGroup(it.name) && it.channels.isNotEmpty() }
        val m3u = content?.m3uSources.orEmpty()
        val total = groups.size + m3u.size
        if (total == 0) {
            showList("القنوات المباشرة", "0 باقة", listOf(Row("__e", "لا توجد قنوات حالياً")), false) { }
            return
        }

        val favSet = loadList("favs").map { firstUrl(it) }.toMutableSet()
        var items: List<Channel> = emptyList()
        var curGroup = -1
        val bars = ArrayList<View>()
        val pkgViews = ArrayList<View>()

        val chTitle = TextView(this).apply {
            setTextColor(MUTED); textSize = 14f; typeface = FONT_MED
            setPadding(dp(6), 0, dp(6), dp(10))
        }
        val chAdapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(p: Int) = items[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
                val ch = items[p]
                val gi = curGroup
                val grp = groups.getOrNull(gi)
                val grpName = grp?.name.orEmpty()
                val list = items
                return LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(14), dp(10), dp(14), dp(10))
                    addView(TextView(context).apply {
                        text = (p + 1).toString(); setTextColor(ACCENT); textSize = 16f; typeface = FONT_MED
                        gravity = Gravity.CENTER
                        background = surface(10, ACCENT_SOFT, Color.TRANSPARENT, 0)
                    }, LinearLayout.LayoutParams(dp(46), dp(34)).apply { marginEnd = dp(12) })
                    if (ch.logo.isNotBlank()) {
                        val logo = ImageView(context).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
                        ImageLoader.load(ch.logo, logo)
                        addView(logo, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(12) })
                    }
                    addView(TextView(context).apply {
                        text = ch.name; setTextColor(TEXT_MAIN); textSize = 17f; typeface = FONT_MED
                        maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                    }, LinearLayout.LayoutParams(0, WRAP, 1f))
                    val heart = ImageView(context).apply {
                        setImageResource(R.drawable.hz_ic_heart); imageTintList = ColorStateList.valueOf(DANGER)
                        visibility = if (ch.streams.values.firstOrNull() in favSet) View.VISIBLE else View.GONE
                    }
                    addView(heart, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(8) })
                    addView(ImageView(context).apply {
                        setImageResource(R.drawable.hz_ic_play); imageTintList = ColorStateList.valueOf(MUTED)
                    }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(10) })
                    makeFocusable(this, 14, CARD, 1.02f)
                    isClickable = true
                    setOnClickListener {
                        throttle { startPlayback(ch, grpName, list, grpName, { showTvLive(gi) }, groups) }
                    }
                    setOnLongClickListener {
                        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        val added = toggleFav(Entry(ch.name, grpName, ch.streams))
                        val u = ch.streams.values.firstOrNull().orEmpty()
                        if (added) favSet.add(u) else favSet.remove(u)
                        heart.visibility = if (added) View.VISIBLE else View.GONE
                        toast(if (added) "أُضيف إلى المفضلة ♥" else "أُزيل من المفضلة")
                        true
                    }
                    pressFx(this)
                }
            }
        }
        val chList = ListView(this).apply {
            adapter = chAdapter
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(8)
            selector = ColorDrawable(Color.TRANSPARENT)
            itemsCanFocus = true
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            setPadding(dp(4), dp(4), dp(4), dp(24))
        }

        fun select(i: Int) {
            if (i == curGroup) return
            curGroup = i
            items = if (i < groups.size) groups[i].channels else emptyList()
            chTitle.text = if (i < groups.size) "${groups[i].name} · ${items.size} قناة"
            else "مصدر خارجي · اضغط OK لفتحه"
            chAdapter.notifyDataSetChanged()
            chList.setSelection(0)
            bars.forEachIndexed { idx, b -> b.visibility = if (idx == i) View.VISIBLE else View.INVISIBLE }
        }

        // تحريك الريموت على الباقات يبدّل القنوات فوراً (مع تأخير بسيط كي لا يتقطع عند الضغط المستمر)
        var pending: Runnable? = null
        fun scheduleSelect(i: Int) {
            pending?.let { main.removeCallbacks(it) }
            val r = Runnable { select(i) }
            pending = r
            main.postDelayed(r, 90)
        }

        val pkgBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            setPadding(dp(4), dp(4), dp(4), dp(24))
        }
        for (i in 0 until total) {
            val isM3u = i >= groups.size
            val name = if (isM3u) "📡  " + m3u[i - groups.size].name else groups[i].name
            val count = if (isM3u) "مباشر" else groups[i].channels.size.toString()
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(14), dp(14), dp(14))
                val bar = View(context).apply {
                    background = surface(3, ACCENT, Color.TRANSPARENT, 0)
                    visibility = View.INVISIBLE
                }
                bars.add(bar)
                addView(bar, LinearLayout.LayoutParams(dp(4), dp(22)).apply { marginEnd = dp(10) })
                addView(TextView(context).apply {
                    text = name; setTextColor(TEXT_MAIN); textSize = 16f; typeface = FONT_MED
                    maxLines = 1; ellipsize = TextUtils.TruncateAt.END
                }, LinearLayout.LayoutParams(0, WRAP, 1f))
                addView(TextView(context).apply {
                    text = count; setTextColor(MUTED); textSize = 13f; typeface = FONT_MED
                    setPadding(dp(10), dp(3), dp(10), dp(3))
                    background = surface(8, Color.parseColor("#14FFFFFF"), Color.TRANSPARENT, 0)
                }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
                makeFocusable(this, 16, CARD, 1.02f)
                isClickable = true
                setOnClickListener {
                    throttle {
                        if (isM3u) fetchM3u(m3u[i - groups.size]) { showTvLive(i) }
                        else {
                            select(i)
                            chList.getChildAt(0)?.requestFocus()
                        }
                    }
                }
                val prev = onFocusChangeListener
                setOnFocusChangeListener { v, f ->
                    prev?.onFocusChange(v, f)
                    if (f) scheduleSelect(i)
                }
                pressFx(this)
            }
            pkgViews.add(row)
            pkgBox.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        }

        val start = startIndex.coerceIn(0, total - 1)
        select(start)

        show(column().apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(32), dp(22), dp(32), dp(12))
            addView(header("القنوات المباشرة", "$total باقة · اضغط مطولاً على القناة للمفضلة"),
                LinearLayout.LayoutParams(MATCH, WRAP))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                clipChildren = false
                addView(ScrollView(context).apply {
                    isVerticalScrollBarEnabled = false
                    clipChildren = false
                    clipToPadding = false
                    addView(pkgBox, FrameLayout.LayoutParams(MATCH, WRAP))
                }, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginEnd = dp(14) })
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(chTitle, LinearLayout.LayoutParams(MATCH, WRAP))
                    addView(chList, LinearLayout.LayoutParams(MATCH, 0, 1f))
                }, LinearLayout.LayoutParams(0, MATCH, 1.7f))
            }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        })
        // التركيز الأولي على الباقة الحالية (يعمل أيضاً عند الرجوع من المشغّل)
        pkgViews.getOrNull(start)?.post { pkgViews[start].requestFocus() }
    }

    // ---- الأفلام والمسلسلات للتلفزيون: بطاقات كبيرة ----

    private fun showTvVOD() {
        screen = Screen.LIST
        activeAdapterView = null
        navBack = { showHome() }
        setFullscreen(false)
        val xt = content?.xtream
        if (xt == null) {
            showList("الأفلام والمسلسلات", "Xtream غير مضبوط", listOf(Row("__e", "لا يوجد مصدر VOD")), false) { }
            return
        }
        show(column().apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            clipChildren = false
            setPadding(dp(42), dp(24), dp(42), dp(20))
            addView(header("الأفلام والمسلسلات", "محتوى Xtream"), LinearLayout.LayoutParams(MATCH, WRAP))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(tvHomeCard(R.drawable.hz_ic_film, "الأفلام", "Xtream", "التصنيفات والأفلام", true) {
                    loadXtreamMovies(xt)
                }, LinearLayout.LayoutParams(0, dp(270), 1f).apply { marginEnd = dp(10) })
                addView(tvHomeCard(R.drawable.hz_ic_film, "المسلسلات", "Xtream", "المواسم والحلقات", false) {
                    loadXtreamSeries(xt)
                }, LinearLayout.LayoutParams(0, dp(270), 1f).apply { marginStart = dp(10) })
            }, LinearLayout.LayoutParams(MATCH, dp(300)).apply { topMargin = dp(18) })
            if (content?.series.orEmpty().isNotEmpty()) {
                addView(TextView(context).apply {
                    text = "ليل البنفسج     ·     الموسم الثاني"
                    textSize = 21f; typeface = FONT_MED; setTextColor(TEXT_MAIN)
                    gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                    setPadding(dp(28), dp(18), dp(28), dp(18))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(14).toFloat()
                        setColor(Color.parseColor("#19131F"))
                        setStroke(dp(1), ACCENT)
                    }
                    isFocusable = true; isClickable = true
                    setOnClickListener { showSeriesGroups() }
                    setOnFocusChangeListener { v, focused ->
                        v.alpha = if (focused) 1f else .88f
                        v.scaleX = if (focused) 1.015f else 1f
                        v.scaleY = if (focused) 1.015f else 1f
                    }
                }, LinearLayout.LayoutParams(MATCH, dp(76)).apply { topMargin = dp(18) })
            }
        })
    }

    // ---- مؤشر الريموت داخل المتصفح (السيرفرات) ----

    private fun cursorDrawable() = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.argb(225, 255, 255, 255))
        setStroke(dp(2), Color.BLACK)
    }

    private fun placeCursor() {
        val c = tvCursor ?: return
        c.translationX = cursorX - dp(13)
        c.translationY = cursorY - dp(13)
    }

    private fun enterButtonMode() {
        cursorMode = false
        tvCursor?.visibility = View.GONE
        (browserTopBar as? ViewGroup)?.getChildAt(0)?.requestFocus()
        toast("وضع الأزرار · السهم ↓ للعودة إلى المؤشر")
    }

    private fun enterCursorMode() {
        cursorMode = true
        (getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)
            ?.hideSoftInputFromWindow(window.decorView.windowToken, 0)
        tvCursor?.visibility = View.VISIBLE
        webView?.requestFocus()
        placeCursor()
    }

    private fun moveCursor(dx: Float, dy: Float, wv: WebView) {
        val w = wv.width.toFloat()
        val h = wv.height.toFloat()
        val edge = dp(36).toFloat()
        val nx = (cursorX + dx).coerceIn(0f, w)
        var ny = cursorY + dy
        if (dy > 0 && ny > h - edge) {
            if (wv.canScrollVertically(1)) { wv.scrollBy(0, (dy * 2).toInt()); ny = h - edge }
            else ny = minOf(ny, h)
        } else if (dy < 0 && ny < edge) {
            if (wv.canScrollVertically(-1)) { wv.scrollBy(0, (dy * 2).toInt()); ny = edge }
            else if (cursorY <= 1f) { enterButtonMode(); return }
            else ny = maxOf(ny, 0f)
        }
        cursorX = nx
        cursorY = ny.coerceIn(0f, h)
        placeCursor()
    }

    private fun cursorClick(wv: WebView) {
        val x = cursorX
        val y = cursorY
        val t = android.os.SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0)
        wv.dispatchTouchEvent(down)
        down.recycle()
        main.postDelayed({
            val t2 = android.os.SystemClock.uptimeMillis()
            val up = MotionEvent.obtain(t2, t2, MotionEvent.ACTION_UP, x, y, 0)
            wv.dispatchTouchEvent(up)
            up.recycle()
        }, 60)
    }

    /** أزرار الريموت داخل المتصفح: الأسهم تحرّك المؤشر، OK ينقر، القائمة تبدّل الوضع. */
    private fun handleBrowserKey(e: KeyEvent): Boolean {
        val wv = webView ?: return false
        val k = e.keyCode
        val down = e.action == KeyEvent.ACTION_DOWN
        if (k == KeyEvent.KEYCODE_MENU) {
            if (down && e.repeatCount == 0) { if (cursorMode) enterButtonMode() else enterCursorMode() }
            return true
        }
        if (!cursorMode) {
            if (down && k == KeyEvent.KEYCODE_DPAD_DOWN) {
                val f = currentFocus
                val bar = browserTopBar
                if (f != null && bar is ViewGroup && isDescendantOf(f, bar)) { enterCursorMode(); return true }
            }
            return false
        }
        when (k) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (down) {
                    val step = dp(9) * (1f + minOf(e.repeatCount, 15) / 3f)
                    when (k) {
                        KeyEvent.KEYCODE_DPAD_UP -> moveCursor(0f, -step, wv)
                        KeyEvent.KEYCODE_DPAD_DOWN -> moveCursor(0f, step, wv)
                        KeyEvent.KEYCODE_DPAD_LEFT -> moveCursor(-step, 0f, wv)
                        else -> moveCursor(step, 0f, wv)
                    }
                }
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (down && e.repeatCount == 0) cursorClick(wv)
                return true
            }
            KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                if (down) wv.scrollBy(0, wv.height * 2 / 3)
                return true
            }
            KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_MEDIA_REWIND -> {
                if (down) wv.scrollBy(0, -wv.height * 2 / 3)
                return true
            }
        }
        return false
    }

    // ================= UI Toolkit =================

    private fun show(v: View, slide: Boolean = true) {
        destroyWebView()
        stopPlayer()
        while (root.childCount > 1) root.removeViewAt(1)
        bgView.visibility = View.VISIBLE
        root.addView(v, MATCH, MATCH)
        v.alpha = 0f
        if (slide) v.translationY = dp(14).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(280)
            .setInterpolator(DecelerateInterpolator()).start()
        if (isTvDevice() || isTvMode()) v.post { focusFirst(v) }
    }

    /** يميّز أجهزة أندرويد تي في (ريموت)، لمعرفة متى نحتاج تركيزاً أولياً صريحاً. */
    private fun isTvDevice(): Boolean {
        val lean = packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
        val uiMode = (getSystemService(UI_MODE_SERVICE) as? UiModeManager)
            ?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
        return lean || uiMode
    }

    /** يضع تركيز الريموت على أول عنصر قابل للتحكم في الشاشة، فلا يحتاج المستخدم لمس الشاشة أولاً. */
    private fun focusFirst(v: View): Boolean {
        if (v.isFocusable && v.visibility == View.VISIBLE && v.isEnabled) {
            if (v is ViewGroup && v.childCount > 0 && v !is AdapterView<*>) {
                // نفضّل أول طفل قابل للتركيز حقيقة (مثل بطاقة أو زر) على الحاوية نفسها
            } else {
                return v.requestFocus()
            }
        }
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) if (focusFirst(v.getChildAt(i))) return true
        }
        return false
    }

    private fun throttle(action: () -> Unit) {
        val now = System.currentTimeMillis()
        if (now - lastClickTime < 300) return
        lastClickTime = now
        action()
    }

    private fun showList(
        titleText: String,
        subtitle: String,
        rows: List<Row>,
        searchable: Boolean,
        onLongClick: ((Row) -> Unit)? = null,
        onClick: (Row) -> Unit
    ) {
        var shown = rows
        val adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(p: Int) = shown[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun isEnabled(p: Int) = !shown[p].key.startsWith("__")
            override fun getView(p: Int, cv: View?, g: ViewGroup): View =
                rowView(shown[p], onClick, onLongClick)
        }
        val lv = ListView(this).apply {
            this.adapter = adapter
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(10)
            selector = ColorDrawable(Color.TRANSPARENT)
            isFocusable = true
            isFocusableInTouchMode = false
            if (isTvMode()) {
                itemsCanFocus = true
                descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            }
            clipToPadding = false
            setPadding(0, 0, 0, dp(24))
        }
        activeAdapterView = lv
        show(column().apply {
            addView(header(titleText, subtitle), LinearLayout.LayoutParams(MATCH, WRAP))
            if (searchable) {
                val search = searchField { q ->
                    shown = if (q.isEmpty()) rows else rows.filter { it.title.contains(q, true) }
                    adapter.notifyDataSetChanged()
                }
                addView(search, LinearLayout.LayoutParams(MATCH, dp(50)).apply { bottomMargin = dp(14) })
            }
            addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        })
        // تحديد أول عنصر صراحةً حتى يعمل زر OK مباشرةً دون لمس الشاشة.
        lv.post { if (lv.count > 0) { lv.setSelection(0); lv.requestFocus() } }
        // دخول متتالي ناعم للبطاقات
        lv.post {
            for (i in 0 until lv.childCount) {
                val c = lv.getChildAt(i)
                c.alpha = 0f
                c.translationY = dp(28).toFloat()
                c.animate().alpha(1f).translationY(0f)
                    .setStartDelay(55L * i).setDuration(360)
                    .setInterpolator(DecelerateInterpolator(1.6f)).start()
            }
        }
    }

    private fun rowView(r: Row, onClick: (Row) -> Unit, onLongClick: ((Row) -> Unit)?): View {
        if (r.key.startsWith("__")) {
            return TextView(this).apply {
                text = r.title
                setTextColor(MUTED)
                textSize = 12f
                typeface = FONT_MED
                letterSpacing = 0.1f
                setPadding(dp(6), dp(18), 0, dp(6))
                isFocusable = false
                isFocusableInTouchMode = false
            }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(16), dp(16), dp(16))
            makeFocusable(this, 16, CARD, 1.02f)
            isClickable = true
            setOnClickListener { throttle { onClick(r) } }
            if (onLongClick != null) setOnLongClickListener {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                throttle { onLongClick(r) }; true
            }
            pressFx(this)
        }
        row.addView(TextView(this).apply {
            text = r.title; setTextColor(TEXT_MAIN); textSize = 16f; typeface = FONT_MED
        }, LinearLayout.LayoutParams(0, WRAP, 1f))

        r.badges.forEach { b ->
            val hot = b == "FHD" || b == "HD"
            row.addView(TextView(this).apply {
                text = b
                setTextColor(if (hot) ACCENT else MUTED)
                textSize = 11f
                typeface = FONT_MED
                setPadding(dp(10), dp(3), dp(10), dp(3))
                background = surface(8, if (hot) ACCENT_SOFT else Color.parseColor("#14FFFFFF"), Color.TRANSPARENT, 0)
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(6) })
        }
        val trailRes: Int; val trailTint: Int; val trailSize: Int
        when (r.trailing) {
            "♥" -> { trailRes = R.drawable.hz_ic_heart; trailTint = DANGER; trailSize = 20 }
            "♡" -> { trailRes = R.drawable.hz_ic_heart_outline; trailTint = MUTED; trailSize = 20 }
            "▶" -> { trailRes = R.drawable.hz_ic_play; trailTint = ACCENT; trailSize = 18 }
            else -> { trailRes = R.drawable.hz_ic_chevron; trailTint = MUTED; trailSize = 18 }
        }
        row.addView(ImageView(this).apply {
            setImageResource(trailRes); imageTintList = ColorStateList.valueOf(trailTint)
        }, LinearLayout.LayoutParams(dp(trailSize), dp(trailSize)).apply { marginStart = dp(12) })
        return row
    }

    private fun badgeColor(b: String) = when (b) {
        "FHD" -> ACCENT2
        "HD" -> ACCENT
        "SD" -> MUTED
        else -> ACCENT
    }

    private fun withAlpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** عدد الأعمدة حسب عرض الشاشة: هاتف 3، تابلت/تي في أوسع. */
    private fun gridColumns(): Int {
        val wdp = resources.displayMetrics.widthPixels / resources.displayMetrics.density
        return when {
            wdp >= 900 -> 6
            wdp >= 600 -> 5
            wdp >= 420 -> 4
            else -> 3
        }
    }
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    /** ضغطة ناعمة: تصغير سريع ثم ارتداد خفيف + اهتزاز دقيق. */
    private fun pressFx(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator(2.4f)).start()
            }
            false
        }
    }

    /** نبض هادئ للشعار، ويتوقف عند إزالته من الشاشة. */
    private fun pulse(v: View) {
        val a = ValueAnimator.ofFloat(1f, 1.06f).apply {
            duration = 1800
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { v.scaleX = it.animatedValue as Float; v.scaleY = it.animatedValue as Float }
            start()
        }
        v.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(x: View) {}
            override fun onViewDetachedFromWindow(x: View) { a.cancel() }
        })
    }

    private fun roundedLogo(size: Int, radius: Int) = ImageView(this).apply {
        setImageResource(R.drawable.horizon_logo)
        scaleType = ImageView.ScaleType.CENTER_CROP
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(radius).toFloat())
            }
        }
        clipToOutline = true
    }

    private fun gradientText(t: String, size: Float) = TextView(this).apply {
        text = t
        textSize = size
        typeface = FONT_MED
        setTextColor(TEXT_MAIN)
    }

    private fun header(t: String, sub: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, 0, 0, dp(18))
        if (navBack != null) addView(roundButton(R.drawable.hz_ic_back, "رجوع") { goBack() },
            LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(14) })
        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply {
                text = t; setTextColor(TEXT_MAIN); textSize = 24f; typeface = FONT_MED
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            })
            addView(TextView(context).apply {
                text = sub; setTextColor(MUTED); textSize = 12f; setPadding(0, dp(2), 0, 0)
            })
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
    }

    private fun surface(radiusDp: Int, fill: Int = CARD, stroke: Int = BORDER, strokeDp: Int = 1) =
        GradientDrawable().apply {
            cornerRadius = dp(radiusDp).toFloat()
            setColor(fill)
            setStroke(dp(strokeDp), stroke)
        }

    /** خلفية بطاقة مع إبراز بلون التمييز عند التركيز (ريموت التلفاز) وتكبير خفيف. */
    private fun makeFocusable(v: View, radiusDp: Int, fill: Int = CARD, scale: Float = 1.03f) {
        val normal = surface(radiusDp, fill)
        val focused = surface(radiusDp, CARD_FOCUS, ACCENT, 2)
        val ripple = ColorStateList.valueOf(Color.parseColor("#22FFFFFF"))
        v.isFocusable = true
        v.isFocusableInTouchMode = false
        v.background = RippleDrawable(ripple, normal, null)
        v.setOnFocusChangeListener { _, f ->
            v.background = RippleDrawable(ripple, if (f) focused else normal, null)
            v.animate().scaleX(if (f) scale else 1f).scaleY(if (f) scale else 1f).setDuration(150).start()
        }
    }

    private fun roundButton(res: Int, desc: String, onClick: () -> Unit): ImageView = ImageView(this).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(TEXT_MAIN)
        scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        contentDescription = desc
        makeFocusable(this, 22, CARD, 1.08f)
        isClickable = true
        setOnClickListener { throttle { onClick() } }
    }

    private fun searchField(onQuery: (String) -> Unit): EditText = EditText(this).apply {
        hint = "بحث"
        setHintTextColor(MUTED)
        setTextColor(TEXT_MAIN)
        setSingleLine()
        textSize = 15f
        setPadding(dp(18), 0, dp(18), 0)
        compoundDrawablePadding = dp(10)
        androidx.core.content.ContextCompat.getDrawable(context, R.drawable.hz_ic_search)?.mutate()?.let { d ->
            d.setTint(MUTED)
            setCompoundDrawablesRelativeWithIntrinsicBounds(d, null, null, null)
        }
        background = surface(16, CARD)
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { onQuery(s?.toString()?.trim().orEmpty()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(20), dp(32), dp(20), dp(12))
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(MUTED); textSize = 14f
        gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(8))
    }

    private fun title(t: String) = gradientText(t, 24f).apply {
        gravity = Gravity.CENTER
        setPadding(0, dp(4), 0, dp(12))
    }

    private fun button(t: String, filled: Boolean = true, onClick: () -> Unit) = Button(this).apply {
        text = t; textSize = 15f; typeface = FONT_MED
        setAllCaps(false)
        stateListAnimator = null
        setTextColor(if (filled) ON_ACCENT else TEXT_MAIN)
        isFocusable = true; isFocusableInTouchMode = false

        val normal = if (filled) surface(16, ACCENT, Color.TRANSPARENT, 0) else surface(16, CARD)
        val focused = if (filled) surface(16, ACCENT, Color.WHITE, 2) else surface(16, CARD_FOCUS, ACCENT, 2)
        val ripple = ColorStateList.valueOf(Color.parseColor("#33FFFFFF"))
        background = RippleDrawable(ripple, normal, null)
        setOnFocusChangeListener { _, f ->
            background = RippleDrawable(ripple, if (f) focused else normal, null)
            animate().scaleX(if (f) 1.04f else 1f)
                .scaleY(if (f) 1.04f else 1f).setDuration(160).start()
        }
        setOnClickListener { throttle { onClick() } }
        pressFx(this)
    }

    private fun chip(t: String, selected: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 12f; typeface = FONT_MED
        gravity = Gravity.CENTER; setPadding(dp(16), 0, dp(16), 0)
        setTextColor(if (selected) ON_ACCENT else Color.WHITE)
        isFocusable = true; isFocusableInTouchMode = false
        background = if (selected) surface(20, ACCENT, Color.TRANSPARENT, 0)
        else surface(20, Color.parseColor("#99000000"), BORDER, 1)
        setOnFocusChangeListener { _, f ->
            animate().scaleX(if (f) 1.1f else 1f)
                .scaleY(if (f) 1.1f else 1f).setDuration(150).start()
        }
        setOnHoverListener { view, event ->
            if (event.action == MotionEvent.ACTION_HOVER_ENTER) view.requestFocus()
            false
        }
        setOnClickListener { throttle { onClick() } }
        pressFx(this)
    }

}
