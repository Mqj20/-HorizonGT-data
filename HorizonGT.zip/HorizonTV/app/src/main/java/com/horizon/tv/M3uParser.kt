package com.horizon.tv

import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import java.net.URL

/** يجلب قائمة تشغيل M3U خارجية ويحوّلها إلى أقسام وقنوات، كأي مصدر قنوات آخر في التطبيق. */
object M3uParser {
    private val ui = Handler(Looper.getMainLooper())

    fun async(work: () -> List<Group>, done: (Result<List<Group>>) -> Unit) {
        Thread {
            val r = runCatching(work)
            ui.post { done(r) }
        }.start()
    }

    fun fetchGroups(url: String): List<Group> = parse(fetch(url))

    private fun fetch(u: String, redirects: Int = 5): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 12000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "HorizonTV/1.0")
        val code = c.responseCode
        if (code in 300..399 && redirects > 0) {
            val loc = c.getHeaderField("Location") ?: return c.inputStream.bufferedReader().use { it.readText() }
            return fetch(loc, redirects - 1)
        }
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private val groupRegex = Regex("""group-title="([^"]*)"""")
    private val logoRegex = Regex("""tvg-logo="([^"]*)"""")

    private fun parse(text: String): List<Group> {
        val order = LinkedHashMap<String, MutableList<Channel>>()
        var pendingName = ""
        var pendingGroup = "عام"
        var pendingLogo = ""

        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    pendingGroup = groupRegex.find(line)?.groupValues?.get(1)?.trim().orEmpty().ifBlank { "عام" }
                    pendingLogo = logoRegex.find(line)?.groupValues?.get(1)?.trim().orEmpty()
                    pendingName = line.substringAfterLast(',').trim().ifBlank { "قناة" }
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    val list = order.getOrPut(pendingGroup) { mutableListOf() }
                    list.add(Channel(pendingName, linkedMapOf("Live" to line), pendingLogo))
                    pendingName = ""; pendingGroup = "عام"; pendingLogo = ""
                }
            }
        }
        return order.map { (name, list) -> Group(name, list) }.filter { it.channels.isNotEmpty() }
    }
}
