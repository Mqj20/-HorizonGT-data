package com.horizon.tv

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import java.net.NetworkInterface

/** يكشف أدوات مراقبة الشبكة: VPN (مثل HTTP Canary وPacket Capture) أو بروكسي. */
object Guard {
    fun reason(ctx: Context): String? {
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            @Suppress("DEPRECATION")
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return "VPN"
            }
            if (Build.VERSION.SDK_INT >= 23 && cm.defaultProxy != null) return "Proxy"
        } catch (e: Exception) { }
        try {
            if (!System.getProperty("http.proxyHost").isNullOrBlank()) return "Proxy"
        } catch (e: Exception) { }
        try {
            val ifs = NetworkInterface.getNetworkInterfaces()
            while (ifs != null && ifs.hasMoreElements()) {
                val i = ifs.nextElement()
                val n = i.name ?: continue
                if (i.isUp && (n.startsWith("tun") || n.startsWith("ppp") || n.startsWith("tap") || n.startsWith("ipsec"))) return "VPN"
            }
        } catch (e: Exception) { }
        return null
    }
}
