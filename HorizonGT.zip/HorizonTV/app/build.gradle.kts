plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.horizon.tv"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.horizon.gt"
        minSdk = 23
        targetSdk = 34
        versionCode = 14
        versionName = "5.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    // توقيع ثابت: بدونه كل بناء على GitHub يُوقَّع بمفتاح مختلف ولا يتحدّث فوق النسخة القديمة
    val ksPath = System.getenv("KEYSTORE_PATH")
    if (ksPath != null) {
        signingConfigs {
            create("fixed") {
                storeFile = file(ksPath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS") ?: "horizon"
                keyPassword = System.getenv("KEYSTORE_PASSWORD")
            }
        }
        buildTypes {
            getByName("release") { signingConfig = signingConfigs.getByName("fixed") }
            getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        }
    }
    kotlinOptions {
        jvmTarget = "17"
        // Media3 يعلّم واجهاته الأساسية @UnstableApi؛ بدون هذا السطر يفشل بناء Kotlin
        freeCompilerArgs += "-opt-in=androidx.media3.common.util.UnstableApi"
    }

}
dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    // AndroidX Media3: successor to ExoPlayer, with dedicated HLS and DASH modules.
    val media3Version = "1.9.0"
    implementation("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-exoplayer-hls:$media3Version")
    implementation("androidx.media3:media3-exoplayer-dash:$media3Version")
    implementation("androidx.media3:media3-exoplayer-rtsp:$media3Version")
    implementation("androidx.media3:media3-ui:$media3Version")
    // مفكّك FFmpeg برمجي لأصوات لا يدعمها الجهاز (MP2 وAC3 وغيرها)؛ نفس إصدار Media3
    implementation("org.jellyfin.media3:media3-ffmpeg-decoder:$media3Version+1")
    implementation("com.google.android.gms:play-services-ads:23.6.0")
}
