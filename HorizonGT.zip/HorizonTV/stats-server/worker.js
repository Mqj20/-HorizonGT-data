// Cloudflare Worker (مجاني) لعدّاد Horizon TV
// الإعداد: KV Namespace باسم STATS مربوط بالـ Worker، ومتغير سري STATS_KEY (كلمة سر تختارها أنت).
// التطبيق يرسل POST إلى /hit ، وأنت تفتح: https://<worker>/stats?key=كلمة_السر

const num = async (kv, k) => parseInt((await kv.get(k)) || "0", 10);

async function countOnline(kv) {
  let n = 0, cursor;
  do {
    const r = await kv.list({ prefix: "online:", cursor });
    n += r.keys.length;
    cursor = r.list_complete ? undefined : r.cursor;
  } while (cursor);
  return n;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);

    if (url.pathname === "/hit" && req.method === "POST") {
      let b;
      try { b = await req.json(); } catch { return new Response("bad", { status: 400 }); }
      const id = String(b.id || "").slice(0, 64);
      if (!/^[0-9a-f-]{20,64}$/i.test(id)) return new Response("bad", { status: 400 });
      const kv = env.STATS;

      // فاتح الآن: يبقى 4 دقائق بعد آخر نبضة
      await kv.put("online:" + id, "1", { expirationTtl: 240 });

      // محمّل: جهاز جديد يُحسب مرة واحدة فقط
      if (!(await kv.get("dev:" + id))) {
        await kv.put("dev:" + id, "1");
        await kv.put("devices", String((await num(kv, "devices")) + 1));
      }
      return new Response("ok");
    }

    if (url.pathname === "/stats") {
      if (!env.STATS_KEY || url.searchParams.get("key") !== env.STATS_KEY)
        return new Response("forbidden", { status: 403 });
      const kv = env.STATS;
      const html = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="30">
<body style="font-family:sans-serif;background:#0A0B0F;color:#F4F5F7;padding:32px;direction:rtl;text-align:center">
<h2>Horizon TV</h2>
<div style="font-size:18px;color:#8A8F9C">🟢 فاتح النسخة الآن</div>
<div style="font-size:64px;font-weight:bold;margin-bottom:28px">${await countOnline(kv)}</div>
<div style="font-size:18px;color:#8A8F9C">📥 محمّل النسخة</div>
<div style="font-size:64px;font-weight:bold">${await num(kv, "devices")}</div>
</body>`;
      return new Response(html, { headers: { "content-type": "text/html;charset=utf-8" } });
    }
    return new Response("Horizon stats", { status: 200 });
  },
};
