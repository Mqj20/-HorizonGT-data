# Horizon GT — Remote content.json

نسخة Horizon GT تعتمد على **ملف واحد فقط لإدارة المحتوى**: `content.json`.

## كيف تعمل البيانات

- التطبيق يجلب `content.json` مباشرة من GitHub عند التشغيل وعند تحديث المحتوى.
- القنوات والباقات والروابط الموجودة في `channels` داخل الملف تتحكم بها مباشرة.
- إعداد Xtream موجود داخل نفس `content.json` في الحقل `xtream`.
- الأفلام والمسلسلات تُجلب مباشرة من Xtream باستخدام بيانات `xtream` الموجودة في `content.json`.
- حذف قناة من `content.json` يحذفها من التطبيق بعد التحديث.
- تغيير حساب Xtream في `content.json` يغيّر مصدر الأفلام والمسلسلات بدون إعادة بناء APK.

## ملف البيانات

المصدر المبرمج حالياً هو:

`https://raw.githubusercontent.com/Mqj20/horizon-data/main/content.json`

يجب أن يكون مستودع البيانات عاماً حتى يستطيع التطبيق قراءة الملف مباشرة بدون GitHub token.

## مهم بخصوص Xtream

بيانات Xtream تُقرأ حصرياً من الحقل `xtream` داخل `content.json` (يدعم الملف النص العادي أو القيم المشفرة). لا توجد بيانات اشتراك ثابتة داخل كود التطبيق. لا تضع GitHub token داخل التطبيق.

تنبيه: إذا كان مستودع البيانات عاماً، فبيانات الدخول الموجودة في `content.json` ستكون قابلة للقراءة لمن يستطيع الوصول إلى الملف؛ استخدم مستودعاً خاصاً أو بيانات تجريبية عند الحاجة.

## البناء

المشروع يستخدم Android Gradle Plugin 8.6.1 وGradle 8.7، مع AndroidX Media3. يمكن البناء من GitHub Actions أو Android Studio.

## GitHub Actions

ملف البناء موجود في `.github/workflows/build-apk.yml` ويبني Debug وRelease ويرفعهما كـ Artifact.
